#' Write the role license report to Excel
#'
#' Writes the result of \code{\link{analyze_role_license_report}} as a
#' workbook for the business department: an overview in plain words, the
#' building blocks of the role with their license, all duties and privileges,
#' the objects behind a base license and, when the report has them, the usage
#' per user.
#'
#' @details
#'
#' **File**
#'
#' The file is named after the role and after what it holds:
#'
#' \describe{
#'   \item{\code{D365FO_License_Report_<role>.xlsx}}{User sheets with real
#'     user ids.}
#'   \item{\code{D365FO_License_Report_<role>_pseudonymized.xlsx}}{User
#'     sheets with pseudonyms.}
#'   \item{\code{D365FO_License_Report_<role>_without_users.xlsx}}{No user
#'     sheets.}
#' }
#'
#' A report in another language than English carries the language at the
#' end, for example \code{D365FO_License_Report_<role>_pseudonymized_de.xlsx},
#' so the languages can share one folder.
#'
#' Characters that are not allowed in file names become \code{_}. An existing
#' file of the same name is overwritten.
#'
#' **Language**
#'
#' Without \code{language} and \code{translations} the report is English.
#' \code{language = "de"} writes the texts in German; the names of roles,
#' duties and privileges stay as D365FO returns them.
#'
#' A translation table replaces these names by its labels and, without
#' \code{language}, also switches the texts to its language. The report has
#' texts for \code{"en"} and \code{"de"}; for a table in any other language it
#' warns, keeps the English texts and still uses the labels. Objects the table
#' does not list keep the name D365FO returns.
#'
#' The table has one row per object and the columns:
#'
#' \describe{
#'   \item{\code{TYPE}}{\code{"Role"}, \code{"Duty"} or \code{"Privilege"}.}
#'   \item{\code{IDENTIFIER}}{AOT name of the object.}
#'   \item{\code{LABEL}}{Name to show.}
#'   \item{\code{LANGUAGE}}{Language code, the same in every row, for example
#'     \code{"de"}.}
#' }
#'
#' **Personal data**
#'
#' The sheets from "User overview" on name users. \code{with_users = FALSE}
#' leaves them out. To pass the file on with pseudonyms instead, run
#' \code{\link{analyze_role_license_report}} with \code{anonymize = TRUE}.
#'
#' @param report
#' Result of \code{\link{analyze_role_license_report}}.
#'
#' @param export_folder
#' Folder to write to. Created when missing. Default: \code{"Data"}.
#'
#' @param translations
#' Translation table as a data frame, or the path of an Excel file whose
#' first sheet holds it. \code{NULL} = English report with the names from
#' D365FO.
#'
#' @param with_users
#' \code{FALSE} = leave out the sheets with usage per user. Default:
#' \code{TRUE}.
#'
#' @param language
#' Language of the report texts: \code{"en"} or \code{"de"}. \code{NULL} =
#' the language of \code{translations}, otherwise English. Must match the
#' language of \code{translations} when both are given.
#'
#' @return
#' Path of the written file.
#'
#' @examples
#' \dontrun{
#'
#' report <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage)
#'
#' # English, with the names from D365FO
#' export_role_license_report(report)
#'
#' # German texts, with the names from D365FO
#' export_role_license_report(report, language = "de")
#'
#' # German with pseudonyms instead of user ids, to pass on
#' report_pseudonyms <- analyze_role_license_report(
#'   cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage,
#'   anonymize = TRUE, key_path = "C:/Keys/anonymization_key.xlsx"
#' )
#' export_role_license_report(report_pseudonyms, language = "de")
#'
#' # German texts and names, without the user sheets
#' export_role_license_report(
#'   report,
#'   translations = "Data/security_object_names_de.xlsx",
#'   with_users   = FALSE
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{analyze_role_license_report}}
#' \code{\link{report_role_license}}
#'
#' @export
export_role_license_report <- function(
  report,
  export_folder = "Data",
  translations  = NULL,
  with_users    = TRUE,
  language      = NULL
) {

  .check_role_report(report, .REPORT_ROLE_TABLES)
  .check_single_role(report$Role$IDENTIFIER)

  if (!.is_single_string(export_folder)) {
    stop("export_folder must be the path of one folder.")
  }
  if (!is.logical(with_users) || length(with_users) != 1L || is.na(with_users)) {
    stop("with_users must be TRUE or FALSE.")
  }

  translations  <- .read_report_translations(translations)
  text_language <- .report_language(translations, language)
  texts         <- .report_texts(text_language)
  report        <- .translate_report(report, translations)
  has_users     <- with_users && .has_user_tables(report)
  file_name     <- .report_file_name(report$Role, has_users, .report_file_language(translations, text_language))

  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  styles   <- .report_styles(texts)

  .add_role_sheets(workbook, report, texts, styles, has_users)
  if (has_users) {
    .add_user_sheets(workbook, report, texts, styles)
  }

  if (!dir.exists(export_folder)) {
    dir.create(export_folder, recursive = TRUE)
  }

  export_path <- file.path(export_folder, file_name)

  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)

  export_path
}

# The name says what the file holds, so that a report with real user ids never
# replaces one that is meant to be passed on, or the other way round. The
# language is added unless it is English, so the languages can share a folder.
.report_file_name <- function(role, has_users, language = .REPORT_DEFAULT_LANGUAGE) {

  content <- if (!has_users) {
    "_without_users"
  } else if (isTRUE(role$ANONYMIZED)) {
    "_pseudonymized"
  } else {
    ""
  }

  # the language of a translation table is data from a file: letters only
  language_part <- if (identical(language, .REPORT_DEFAULT_LANGUAGE)) "" else paste0("_", gsub("[^a-z]", "", language))

  paste0(
    "D365FO_License_Report_", gsub("[^A-Za-z0-9_-]", "_", role$IDENTIFIER), content, language_part, ".xlsx"
  )
}

.REPORT_ROLE_TABLES <- c(
  "Role", "Blocks", "Duties", "Privileges", "Objects",
  "SingleLicenseOptions", "RoleNeed", "ObjectNeeds"
)
.REPORT_USER_TABLES <- c(
  "Licenses", "Users", "UserLicenses", "UserBlocks",
  "DutyUsage", "UserDutyUsage", "OtherRoles"
)

.BULLET <- "• "

.OVERVIEW_WIDTHS <- c(34, 22, 52, 46, 34, 90)

.has_user_tables <- function(report) {
  all(.REPORT_USER_TABLES %in% names(report)) && nrow(report$Users) > 0L
}

# =============================================================================
# Sheets of the role
# =============================================================================

.add_role_sheets <- function(workbook, report, texts, styles, has_users) {

  sheets <- texts$sheets_role

  .add_text_sheet(workbook, sheets[[1]], .overview_parts(report, texts, has_users), styles, .OVERVIEW_WIDTHS)
  .add_table_sheet(workbook, sheets[[2]], .blocks_sheet(report, texts), styles)
  .add_table_sheet(workbook, sheets[[3]], .duties_sheet(report, texts), styles)
  .add_table_sheet(workbook, sheets[[4]], .privileges_sheet(report, texts), styles)
  .add_table_sheet(workbook, sheets[[5]], .objects_sheet(report, texts), styles)
  .add_table_sheet(workbook, sheets[[6]], .all_objects_sheet(report, texts), styles)

  invisible(workbook)
}

.blocks_sheet <- function(report, texts) {

  blocks <- .sort_by_need(report$Blocks, report$Blocks$BLOCK_TYPE, report$Blocks$BLOCK_NAME)

  list(
    data = .sheet_table(
      texts$columns_blocks,
      unname(texts$block_types[blocks$BLOCK_TYPE]),
      blocks$BLOCK_NAME,
      blocks$BLOCK_ID,
      .need_label(blocks$NEED, blocks$IS_BASE, texts),
      .level_label(blocks$NEED, blocks$IS_BASE, texts),
      blocks$OBJECT_COUNT,
      blocks$BASE_OBJECT_COUNT,
      blocks$FIXING_OBJECT_COUNT,
      "", ""
    ),
    highlight = blocks$IS_BASE,
    widths    = c(12, 58, 44, 44, 22, 10, 14, 16, 20, 40)
  )
}

.duties_sheet <- function(report, texts) {

  duties <- .sort_by_need(report$Duties, report$Duties$DUTYNAME)

  list(
    data = .sheet_table(
      texts$columns_duties,
      duties$DUTYNAME,
      duties$DUTYIDENTIFIER,
      unname(texts$assignment[duties$ASSIGNMENT]),
      duties$SUBROLES,
      .need_label(duties$NEED, duties$IS_BASE, texts),
      .level_label(duties$NEED, duties$IS_BASE, texts),
      duties$PRIVILEGE_COUNT,
      duties$OBJECT_COUNT,
      duties$BASE_OBJECT_COUNT,
      "", ""
    ),
    highlight = duties$IS_BASE,
    widths    = c(62, 44, 20, 40, 44, 22, 9, 10, 12, 20, 40)
  )
}

.privileges_sheet <- function(report, texts) {

  privileges <- .sort_by_need(
    report$Privileges, report$Privileges$DUTYNAME, report$Privileges$PRIVILEGENAME
  )
  is_direct <- privileges$DUTYIDENTIFIER == .DIRECT_DUTY_ID

  list(
    data = .sheet_table(
      texts$columns_privileges,
      ifelse(is_direct, texts$direct_duty, privileges$DUTYNAME),
      ifelse(is_direct, texts$direct_short, privileges$DUTYIDENTIFIER),
      privileges$PRIVILEGENAME,
      privileges$PRIVILEGEIDENTIFIER,
      .need_label(privileges$NEED, privileges$IS_BASE, texts),
      .level_label(privileges$NEED, privileges$IS_BASE, texts),
      privileges$OBJECT_COUNT,
      privileges$BASE_OBJECT_COUNT
    ),
    highlight = privileges$IS_BASE,
    widths    = c(56, 40, 62, 44, 44, 22, 10, 12)
  )
}

.objects_sheet <- function(report, texts) {

  objects   <- report$Objects
  all_base  <- rep(TRUE, nrow(objects))
  no_weight <- rep(0, nrow(objects))
  objects   <- objects[.order_by_need(objects$NEED, all_base, no_weight, objects$ENTRYPOINT), ]

  list(
    data = .sheet_table(
      texts$columns_objects,
      .need_label(objects$NEED, all_base, texts),
      objects$ENTRYPOINT,
      objects$ENTRYPOINTTYPE,
      texts$yes_no[ifelse(objects$MEASURABLE, 1L, 2L)],
      gsub(.DIRECT_DUTY_ID, texts$direct_short, objects$ORIGIN, fixed = TRUE)
    ),
    highlight = rep(FALSE, nrow(objects)),
    widths    = c(44, 46, 28, 12, 110)
  )
}

# Every object of the role. compare_role_license_with_d365() reads this sheet
# back by column position: object, type, access and covering licenses must
# stay in the columns named in .ALL_OBJECTS_COLUMNS.
.all_objects_sheet <- function(report, texts) {

  objects <- .sort_by_need(report$ObjectNeeds, report$ObjectNeeds$ENTRYPOINT)

  list(
    data = .sheet_table(
      texts$columns_all_objects,
      objects$ENTRYPOINT,
      objects$ENTRYPOINTTYPE,
      .access_label(objects$ACCESSLEVEL),
      .need_label(objects$NEED, objects$IS_BASE, texts),
      .level_label(objects$NEED, objects$IS_BASE, texts),
      objects$COVERED_BY
    ),
    highlight = objects$IS_BASE,
    widths    = c(46, 28, 10, 44, 22, 90)
  )
}

.sort_by_need <- function(table, ...) {
  table[.order_by_need(table$NEED, table$IS_BASE, table$NEED_PRIORITY, ...), ]
}

# =============================================================================
# Overview
# =============================================================================

.overview_parts <- function(report, texts, has_users) {

  sections <- texts$sections_overview

  c(
    list(
      .part("title", sprintf(texts$overview_title, report$Role$NAME)),
      .part("text", texts$overview_subtitle),
      .part("gap"),
      .part("section", sections[["key_points"]]),
      .part("bullets", .key_points(report, texts)),
      .part("gap")
    ),
    .table_section(sections[["fixing"]], .fixing_blocks_table(report, texts)),
    .table_section(sections[["choice"]], .choice_blocks_table(report, texts)),
    .table_section(sections[["options"]], .options_table(report, texts), note = texts$options_note),
    list(
      .part("section", sections[["reading"]]),
      .part("bullets", .reading_lines(texts, has_users)),
      .part("gap"),
      .part("section", sections[["terms"]]),
      .part("bullets", texts$terms),
      .part("gap"),
      .part("section", sections[["limits"]]),
      .part("bullets", .limit_lines(report, texts, has_users))
    )
  )
}

.key_points <- function(report, texts) {
  c(
    .key_role_need(report, texts),
    .key_fixing_blocks(report, texts),
    .key_duty_levels(report, texts),
    .key_object_sets(report, texts),
    .key_subroles(report, texts)
  )
}

# Licenses that have objects no other license covers, cheapest first.
.fixing_license_names <- function(object_needs) {
  fixing <- object_needs[.is_fixing_need(object_needs$NEED, object_needs$IS_BASE), ]
  unique(fixing$NEED[order(fixing$NEED_PRIORITY, fixing$NEED)])
}

.key_role_need <- function(report, texts) {

  need <- report$RoleNeed$NEED

  if (need == .NEED_UNKNOWN) {
    return(texts$key_unknown)
  }
  if (need != .NEED_MULTIPLE) {
    return(sprintf(texts$key_one_license, .join_alternatives(.split_skus(need)[[1]], texts)))
  }

  fixing    <- .fixing_license_names(report$ObjectNeeds)
  uncovered <- sum(!vapply(
    .split_skus(report$ObjectNeeds$COVERED_BY),
    function(covering) any(covering %in% fixing),
    logical(1)
  ))

  if (length(fixing) == 0L) {
    return(sprintf(texts$key_no_common, texts$sheets_role[[5]]))
  }
  if (uncovered == 0L) {
    return(sprintf(texts$key_several, length(fixing), paste(fixing, collapse = .LIST_SEPARATOR)))
  }

  sprintf(texts$key_several_more, paste(fixing, collapse = .LIST_SEPARATOR), uncovered)
}

.key_fixing_blocks <- function(report, texts) {

  blocks <- report$Blocks[.is_fixing_need(report$Blocks$NEED, report$Blocks$IS_BASE), ]

  if (nrow(blocks) == 0L) {
    return(character())
  }

  licenses <- unique(blocks$NEED[order(blocks$NEED_PRIORITY, blocks$NEED)])
  counts   <- vapply(licenses, function(license) sum(blocks$NEED == license), integer(1))

  sprintf(
    texts$key_fixing,
    paste(sprintf(texts$key_fixing_part, counts, licenses), collapse = .LIST_SEPARATOR)
  )
}

.key_duty_levels <- function(report, texts) {

  duties <- report$Duties

  if (nrow(duties) == 0L) {
    return(character())
  }

  cheaper <- duties[!duties$IS_BASE & duties$NEED != .NEED_UNKNOWN, ]
  levels  <- unique(cheaper$NEED[order(-cheaper$NEED_PRIORITY, cheaper$NEED)])
  base    <- sum(duties$IS_BASE)
  unknown <- sum(duties$NEED == .NEED_UNKNOWN)

  parts <- c(
    if (base > 0L) sprintf(texts$key_duties_base, base),
    sprintf(
      texts$key_duties_level,
      vapply(levels, function(level) sum(cheaper$NEED == level), integer(1)),
      levels
    ),
    if (unknown > 0L) sprintf(texts$key_duties_unknown, unknown)
  )

  sprintf(texts$key_duties, nrow(duties), paste(parts, collapse = .LIST_SEPARATOR))
}

.key_object_sets <- function(report, texts) {

  objects <- report$ObjectNeeds
  base    <- objects[objects$IS_BASE, ]

  if (nrow(objects) == 0L) {
    return(character())
  }
  if (nrow(base) == 0L) {
    return(sprintf(texts$key_objects_none, nrow(objects)))
  }

  # three kinds of base license objects: only one license covers, one of
  # several covers, no single license covers every access to the object
  fixing   <- .fixing_license_names(objects)
  counts   <- vapply(fixing, function(license) sum(base$NEED == license), integer(1))
  multiple <- sum(base$NEED == .NEED_MULTIPLE)
  choice   <- nrow(base) - sum(counts) - multiple

  head <- sprintf(texts$key_objects_head, nrow(objects), nrow(base))
  sets <- paste(sprintf(texts$key_objects_part, counts, fixing), collapse = .LIST_SEPARATOR)

  paste(
    c(
      paste0(head, if (length(fixing) > 0L) paste0(": ", sets), "."),
      if (choice > 0L) sprintf(texts$key_objects_choice, choice),
      if (multiple > 0L) sprintf(texts$key_objects_multiple, multiple)
    ),
    collapse = " "
  )
}

.key_subroles <- function(report, texts) {

  subroles <- report$Blocks[report$Blocks$BLOCK_TYPE == .BLOCK_SUBROLE, ]

  if (nrow(subroles) == 0L) {
    return(character())
  }
  if (!any(subroles$IS_BASE)) {
    return(sprintf(texts$key_subroles_none, nrow(subroles)))
  }

  sprintf(texts$key_subroles_some, sum(subroles$IS_BASE), nrow(subroles))
}

.fixing_blocks_table <- function(report, texts) {

  blocks <- .sort_by_need(report$Blocks, report$Blocks$BLOCK_TYPE, report$Blocks$BLOCK_NAME)
  blocks <- blocks[.is_fixing_need(blocks$NEED, blocks$IS_BASE), ]

  .sheet_table(
    texts$columns_fixing,
    .need_label(blocks$NEED, blocks$IS_BASE, texts),
    unname(texts$block_types[blocks$BLOCK_TYPE]),
    blocks$BLOCK_NAME,
    blocks$BLOCK_ID,
    blocks$FIXING_OBJECT_COUNT
  )
}

.choice_blocks_table <- function(report, texts) {

  blocks <- .sort_by_need(report$Blocks, report$Blocks$BLOCK_TYPE, report$Blocks$BLOCK_NAME)
  blocks <- blocks[blocks$IS_BASE & !.is_fixing_need(blocks$NEED, blocks$IS_BASE), ]

  .sheet_table(
    texts$columns_choice,
    .need_label(blocks$NEED, blocks$IS_BASE, texts),
    unname(texts$block_types[blocks$BLOCK_TYPE]),
    blocks$BLOCK_NAME,
    blocks$BLOCK_ID,
    blocks$BASE_OBJECT_COUNT
  )
}

.options_table <- function(report, texts) {

  options <- report$SingleLicenseOptions
  blocks  <- report$Blocks[order(report$Blocks$BLOCK_TYPE, report$Blocks$BLOCK_NAME), ]

  # "Name (technical name)" of every block the license does not cover
  describe <- function(target) {
    dropped <- .blocks_not_covered(blocks, target)
    paste(
      ifelse(
        dropped$BLOCK_NAME == dropped$BLOCK_ID,
        dropped$BLOCK_ID,
        paste0(dropped$BLOCK_NAME, " (", dropped$BLOCK_ID, ")")
      ),
      collapse = "; "
    )
  }

  .sheet_table(
    texts$columns_options,
    options$TARGET_SKU,
    options$BLOCKS_TO_DROP,
    options$DUTIES,
    options$PRIVILEGES,
    options$SUBROLES,
    vapply(options$TARGET_SKU, describe, character(1), USE.NAMES = FALSE)
  )
}

.reading_lines <- function(texts, has_users) {
  c(
    sprintf(texts$reading_role, texts$sheets_role[2:6]),
    texts$reading_marks,
    if (has_users) sprintf(texts$reading_users, texts$sheets_users[[1]])
  )
}

.limit_lines <- function(report, texts, has_users) {

  created  <- if (is.null(report$Role$CREATED)) Sys.Date() else report$Role$CREATED
  database <- report$Role$DATABASE
  source   <- report$Role$SOURCE
  is_known_source <- .is_single_string(source) && source %in% names(texts$limits_sources)

  c(
    sprintf(texts$limits_created, format(created, texts$date_format)),
    if (.is_single_string(database)) sprintf(texts$limits_database, database),
    if (is_known_source) texts$limits_sources[[source]],
    texts$limits,
    if (has_users) sprintf(texts$limits_persons, texts$sheets_users[[1]]) else texts$limits_no_persons,
    if (has_users && isTRUE(report$Role$ANONYMIZED)) texts$limits_pseudonyms
  )
}

# =============================================================================
# Writing sheets
# =============================================================================

.report_styles <- function(texts) {
  list(
    title   = openxlsx::createStyle(fontSize = 14, textDecoration = "bold"),
    section = openxlsx::createStyle(fontSize = 12, textDecoration = "bold"),
    header  = openxlsx::createStyle(
      textDecoration = "bold", fgFill = "#D9E1F2", border = "Bottom",
      wrapText = TRUE, valign = "top"
    ),
    base    = openxlsx::createStyle(fgFill = "#FCE4D6"),
    wrap    = openxlsx::createStyle(wrapText = TRUE, valign = "top"),
    date    = openxlsx::createStyle(numFmt = texts$excel_date_format)
  )
}

# Table with the given column headers; single values fill every row.
.sheet_table <- function(headers, ...) {

  columns <- list(...)

  if (length(columns) != length(headers)) {
    stop("Internal error: ", length(headers), " headers for ", length(columns), " columns.")
  }

  names(columns) <- headers

  tibble::as_tibble(columns, .name_repair = "minimal")
}

# One piece of a text sheet: "title", "section", "text", "bullets", "table"
# or "gap".
.part <- function(kind, content = NULL) {
  list(kind = kind, content = content)
}

# A heading with its table; nothing at all when the table is empty.
.table_section <- function(title, data, note = NULL) {

  if (nrow(data) == 0L) {
    return(list())
  }

  c(
    list(.part("section", title)),
    if (!is.null(note)) list(.part("text", note)),
    list(.part("table", data))
  )
}

.add_text_sheet <- function(workbook, sheet_name, parts, styles, widths) {

  openxlsx::addWorksheet(workbook, sheet_name, gridLines = FALSE)

  row <- 1L
  for (part in parts) {
    row <- .write_part(workbook, sheet_name, part, row, styles)
  }

  openxlsx::setColWidths(workbook, sheet_name, cols = seq_along(widths), widths = widths)

  invisible(workbook)
}

# Writes one part at `row` and returns the row for the next part.
.write_part <- function(workbook, sheet_name, part, row, styles) {

  if (part$kind == "gap") {
    return(row + 1L)
  }
  if (part$kind == "table") {
    return(.write_part_table(workbook, sheet_name, part$content, row, styles))
  }

  lines <- if (part$kind == "bullets") paste0(.BULLET, part$content, recycle0 = TRUE) else part$content

  if (length(lines) == 0L) {
    return(row)
  }

  openxlsx::writeData(workbook, sheet_name, lines, startRow = row, colNames = FALSE)

  # only titles and section headings have a style of their own
  style <- styles[[part$kind]]
  if (!is.null(style)) {
    openxlsx::addStyle(workbook, sheet_name, style, rows = row, cols = 1)
  }

  row + length(lines)
}

.write_part_table <- function(workbook, sheet_name, data, row, styles) {

  openxlsx::writeData(
    workbook, sheet_name, data,
    startRow = row, headerStyle = styles$header, borders = "all"
  )
  openxlsx::addStyle(
    workbook, sheet_name, styles$wrap,
    rows = row + seq_len(nrow(data)), cols = seq_len(ncol(data)),
    gridExpand = TRUE, stack = TRUE
  )

  row + nrow(data) + 2L
}

# `sheet` holds the table (data), the rows to mark as base license
# (highlight) and the column widths.
.add_table_sheet <- function(workbook, sheet_name, sheet, styles) {

  data      <- sheet$data
  data_rows <- seq_len(nrow(data)) + 1L
  all_cols  <- seq_len(ncol(data))

  openxlsx::addWorksheet(workbook, sheet_name)
  openxlsx::writeData(workbook, sheet_name, data, headerStyle = styles$header, withFilter = TRUE)
  openxlsx::freezePane(workbook, sheet_name, firstRow = TRUE)
  openxlsx::setColWidths(workbook, sheet_name, cols = seq_along(sheet$widths), widths = sheet$widths)

  marked <- data_rows[which(sheet$highlight)]
  if (length(marked) > 0L) {
    openxlsx::addStyle(
      workbook, sheet_name, styles$base,
      rows = marked, cols = all_cols, gridExpand = TRUE, stack = TRUE
    )
  }

  date_cols <- which(vapply(data, inherits, logical(1), what = "Date"))
  if (length(date_cols) > 0L && nrow(data) > 0L) {
    openxlsx::addStyle(
      workbook, sheet_name, styles$date,
      rows = data_rows, cols = date_cols, gridExpand = TRUE, stack = TRUE
    )
  }

  invisible(workbook)
}
