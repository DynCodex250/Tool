# =============================================================================
# Texts of the role license report
#
# Used by export_role_license_report(). Every text the report shows comes from
# here, once per language. English is the default; a translation table selects
# another language. All catalogues have the same entries with the same length.
# Placeholders follow sprintf(): %s, %d and, where the word order differs
# between languages, %1$s.
# =============================================================================

.REPORT_DEFAULT_LANGUAGE <- "en"

.report_languages <- function() {
  c("en", "de")
}

.report_texts <- function(language = .REPORT_DEFAULT_LANGUAGE) {
  switch(
    language,
    en = c(.report_role_texts_en(), .report_user_texts_en()),
    de = c(.report_role_texts_de(), .report_user_texts_de()),
    stop("No report texts for language '", language, "'.")
  )
}

.report_role_texts_en <- function() {
  list(
    date_format       = "%Y-%m-%d",
    excel_date_format = "yyyy-mm-dd",
    sheets_role       = c("Overview", "Building blocks", "All duties", "Privileges per duty", "Base license objects", "All objects"),

    yes_no          = c("yes", "no"),
    block_types     = c(Duty = "Duty", Privilege = "Privilege", SubRole = "Sub-role"),
    assignment      = c(DIRECT = "direct", SUBROLE = "through a sub-role"),
    direct_duty     = "(assigned directly to the role)",
    direct_short    = "(direct)",
    level_base      = "Base license",
    level_unknown   = "no information",
    need_only       = "Only %s",
    need_or         = "%1$s or %2$s",
    need_multiple   = "several base licenses",
    need_unknown    = "no license information",
    count_of        = "%1$s of %2$s",
    none            = "none",
    no_license_data = "no license data in D365",

    overview_title    = "License need of the role \"%s\"",
    overview_subtitle = "Which duties and privileges the role contains and which license they trigger",
    sections_overview = c(
      key_points = "Key points",
      fixing     = "These building blocks fix a specific license",
      choice     = "These building blocks need a base license but leave a choice",
      options    = "What would have to go so that a single license is enough",
      reading    = "How to read the sheets",
      terms      = "Terms",
      limits     = "Limits of this report"
    ),

    key_one_license    = "The role needs one license: %s.",
    key_several        = "No single license covers the role. It needs %1$d base licenses: %2$s.",
    key_several_more   = "No single license covers the role. It needs %1$s for certain, and at least one more license for %2$d objects these do not cover.",
    key_no_common      = "No single license covers the role, and no object asks for one license alone. Several licenses are needed; the sheet \"%s\" shows which.",
    key_unknown        = "D365 has no license information for the objects of this role.",
    key_fixing         = "These building blocks tie the role to a license: %s (table below).",
    key_fixing_part    = "%1$d for %2$s",
    key_duties         = "Duties of the role by the license they need (%1$d in total): %2$s.",
    key_duties_base    = "base license %d",
    key_duties_level   = "%2$s %1$d",
    key_duties_unknown = "no license information in D365 %d",
    key_objects_head     = "Of %1$d objects of the role (menu items and data access), %2$d need a base license",
    key_objects_part     = "%1$d only %2$s",
    key_objects_choice   = "For %d of them, one of several licenses is enough.",
    key_objects_multiple = "%d of them need several licenses at once: no single license covers every access the role has to them.",
    key_objects_none     = "None of the %d objects of the role (menu items and data access) needs a base license.",
    key_subroles_none  = "Sub-roles of the role: %d. None needs a base license; the need comes only from duties and privileges assigned directly to the role.",
    key_subroles_some  = "Sub-roles of the role: %2$d, of which with a base license: %1$d.",

    options_note = "The named license does not cover these building blocks. Whether the users need them is for the business department to decide.",
    reading_role = c(
      "Sheet \"%s\": the duties, privileges and sub-roles assigned directly to the role, with their license.",
      "Sheet \"%s\": every duty of the role, including those from sub-roles, with its license.",
      "Sheet \"%s\": which privileges each duty contains, with the license per privilege.",
      "Sheet \"%s\": the single menu items that ask for a base license, and where they come from.",
      "Sheet \"%s\": every object of the role with its access and the licenses that cover it."
    ),
    reading_marks = "Rows with a coloured background need a base license. The columns \"Needed?\" and \"Remark\" are for your entries.",
    reading_users = "Sheets from \"%s\" on: who actually uses the building blocks that need a base license, with a hint per user.",
    terms = c(
      "Duty: a bundle of privileges for one activity, for example \"Maintain orders\".",
      "Privilege: the access to single menu items, reading or writing.",
      "License levels, ascending: Team Members, Operations - Activity, base license (for example Commerce, Finance, Supply Chain Management).",
      "\"Only Commerce\": only this license covers the building block. \"Commerce or Finance\": one of the named licenses is enough.",
      "A duty needs the license that covers all of its objects."
    ),
    limits_created     = "Created on %s. In other environments the role can be composed differently.",
    limits_database    = "Source database: %s.",
    limits_sources     = c(
      graph = "Data source: the license graph of D365 (table LicensingSecurityObjectExplodedGraph).",
      views = "Data source: the security objects and the license views of D365. The license graph (table LicensingSecurityObjectExplodedGraph) is empty or missing in this database."
    ),
    limits = c(
      "The license information comes from the license data of D365. Microsoft can change it with updates.",
      "\"Would have to go\" means: for the users who are to manage with one license. A building block removed from the existing role is lost for all users of the role.",
      "Names of duties and privileges are shown as D365 returns them, or as the translation table names them."
    ),
    limits_no_persons  = "These sheets say nothing about who has the role or which duties are actually used. They contain no personal data.",
    limits_persons     = "The sheets from \"%s\" on contain personal usage data. Pass them on to authorized persons only.",
    limits_pseudonyms  = "User ids are pseudonyms (USER_xxxx_0001). The real ids are only in the key file, which stays in the source environment; deanonymize_workbook() restores them.",

    columns_fixing     = c("License", "Type", "Name", "Technical name", "Objects only this license covers"),
    columns_choice     = c("License", "Type", "Name", "Technical name", "Objects with base license"),
    columns_options    = c("Target: only this license", "Building blocks to drop", "Duties", "Privileges", "Sub-roles", "Which"),
    columns_blocks     = c("Type", "Name", "Technical name", "License", "License level", "Objects",
                           "Objects with base license", "Objects only this license covers",
                           "Needed? (business department)", "Remark"),
    columns_duties     = c("Duty", "Technical name", "In the role", "Sub-roles", "License", "License level",
                           "Privileges", "Objects", "of which with base license",
                           "Needed? (business department)", "Remark"),
    columns_privileges = c("Duty", "Duty, technical", "Privilege", "Privilege, technical", "License",
                           "License level", "Objects", "of which with base license"),
    columns_objects    = c("License", "Object", "Type", "Usage measurable", "Comes from: duty > privilege"),
    columns_all_objects = c("Object", "Type", "Access", "License", "License level", "Covered by")
  )
}

.report_user_texts_en <- function() {
  list(
    sheets_users   = c("User overview", "Users", "Usage of blocks", "Duties by usage", "Usage per user and duty", "Other roles"),
    users_title    = "Use of the role by its users",
    users_subtitle = "Who actually uses the building blocks that need a base license",
    sections_users = c(
      basis    = "Data basis",
      meaning  = "What the usage means for the licenses",
      licenses = "Licenses and their use (number of users)",
      blocks   = "Use per building block (number of users)",
      reading  = "How to read the sheets",
      limits   = "Limits"
    ),

    basis_users      = "Users with the role: %1$d. Usage data exists for %2$d of them, not for %3$d.",
    basis_disabled   = "Disabled users with the role, left out here: %d.",
    basis_window     = "Their last accesses to objects of the role lie between %1$s and %2$s.",
    basis_notes = c(
      "Measured is which forms a user opened. Actions such as posting an invoice are not measured.",
      "\"Objects only this license covers\" tie the role to that license. A user who opens none of them is a candidate for doing without the license in this role; where few of these objects are forms, that is no more than a hint."
    ),
    meaning_judgeable       = "%1$s: %2$d of the users with usage data opened objects that only this license covers, %3$d did not. %4$d of %5$d such objects are measurable.",
    meaning_unclear         = "%1$s: %2$d of the users with usage data opened objects that only this license covers. For the others the usage cannot decide, because only %3$d of %4$d such objects are forms. Clarify with the business department.",
    meaning_no_fixing       = "No object of the role asks for one license alone, so the usage cannot narrow the license need.",
    meaning_no_usage        = "Without usage data nothing can be said about the use of the role.",
    meaning_other_roles     = "Other roles: for %1$d of %2$d users with license data, other roles trigger base licenses of this role as well. A change to this role alone saves no license there (sheet \"%3$s\").",
    meaning_no_license_data = "D365 has no license rows for the users of this role, so their other roles could not be checked.",
    meaning_duties          = "Duties without observed use: no user opened a form of %1$d of the %2$d duties. In %3$d of them, a part with its own license consists only of actions or data access, which cannot be measured. %4$d more duties contain no form at all (sheet \"%5$s\").",
    user_reading = c(
      "Sheet \"%s\": one row per user with the licenses in use and a hint.",
      "Sheet \"%s\": calls and rating per user and building block.",
      "Sheet \"%s\": how many users use each duty. Duties without observed use come first.",
      "Sheet \"%s\": every single value, for filtering.",
      "Sheet \"%s\": the other roles of a user that trigger the same base licenses."
    ),
    user_limits = c(
      "\"No use observed\" means: no form opened in the period of the usage data. A hint, not a proof (stand-ins, rare or seasonal activities).",
      "A building block can be dropped for single users only through a variant of the role. Removed from the existing role, it is lost for all users.",
      "These sheets contain personal usage data. Pass them on to authorized persons only."
    ),

    columns_license_usage = c("License", "Objects only this license covers", "of which measurable", "Users: used",
                              "Users: no use observed", "Users: unclear", "Users: no usage data"),
    columns_block_summary = c("License", "Type", "Building block", "Technical name",
                              "Measurable objects with base license", "Users: base license part used",
                              "Users: only other objects used", "Users: no use observed",
                              "Users: not measurable", "Users: no usage data"),
    columns_users         = c("User", "Usage data", "Hint from the usage", "Licenses in use",
                              "Licenses without observed use", "Licenses the usage cannot judge", "Duties used",
                              "Last access", "Licenses today in D365", "Same base licenses through other roles",
                              "Decision (business department)", "Remark"),
    columns_user_blocks   = c("User", "Type", "Building block", "Technical name", "License of the block", "Calls",
                              "of which objects with base license", "Measurable objects with base license",
                              "Last access", "Rating"),
    columns_duty_usage    = c("Duty", "Technical name", "License", "License level", "Users with use", "Calls",
                              "Last access", "Rating", "Measurable objects", "Needed? (business department)", "Remark"),
    columns_user_duties   = c("User", "Duty", "Technical name", "License", "Calls", "Last access", "Evidence"),
    columns_other_roles   = c("User", "License", "Other role", "Other role, technical"),

    rating_block = c(USED = "base license part used", PARTIAL = "only other objects opened",
                     NOT_USED = "no use observed", NOT_MEASURABLE = "not measurable",
                     NO_DATA = "no usage data"),
    rating_duty  = c(USED = "used", NOT_USED = "no use observed for any user",
                     PARTLY_MEASURABLE = "no use observed for any user, only partly measurable",
                     NOT_MEASURABLE = "not measurable", NO_DATA = "no usage data"),
    evidence     = c(USED = "used", NOT_OBSERVED = "no use observed",
                     NOT_MEASURABLE = "no use observed, only partly measurable", NO_USER_TELEMETRY = "no usage data"),
    hints        = c(
      NO_DATA      = "No usage data: inactive, or the user id differs. Clarify.",
      NOT_OBSERVED = "No use observed for %s: candidate for a variant of the role without the building blocks that need it.",
      UNCLEAR      = "The usage cannot judge %s: clarify with the business department.",
      USED         = "In use: %s.",
      NONE         = "No object of the role asks for one license alone."
    )
  )
}

.report_role_texts_de <- function() {
  list(
    date_format       = "%d.%m.%Y",
    excel_date_format = "DD.MM.YYYY",
    sheets_role       = c("Überblick", "Bausteine der Rolle", "Alle Aufgaben", "Rechte je Aufgabe", "Objekte mit Basislizenz", "Alle Objekte"),

    yes_no          = c("ja", "nein"),
    block_types     = c(Duty = "Aufgabe", Privilege = "Recht", SubRole = "Unterrolle"),
    assignment      = c(DIRECT = "direkt", SUBROLE = "über eine Unterrolle"),
    direct_duty     = "(der Rolle direkt zugewiesen)",
    direct_short    = "(direkt)",
    level_base      = "Basislizenz",
    level_unknown   = "ohne Angabe",
    need_only       = "Nur %s",
    need_or         = "%1$s oder %2$s",
    need_multiple   = "mehrere Basislizenzen",
    need_unknown    = "ohne Lizenzangabe",
    count_of        = "%1$s von %2$s",
    none            = "keine",
    no_license_data = "keine Lizenzdaten in D365",

    overview_title    = "Lizenzbedarf der Rolle „%s“",
    overview_subtitle = "Welche Aufgaben und Rechte in der Rolle stecken und welche Lizenz sie auslösen",
    sections_overview = c(
      key_points = "Das Wichtigste",
      fixing     = "Diese Bausteine legen eine bestimmte Lizenz fest",
      choice     = "Diese Bausteine brauchen eine Basislizenz, lassen aber die Wahl",
      options    = "Was entfallen müsste, damit eine einzige Lizenz genügt",
      reading    = "So lesen Sie die Blätter",
      terms      = "Begriffe",
      limits     = "Grenzen dieses Berichts"
    ),

    key_one_license    = "Die Rolle braucht eine Lizenz: %s.",
    key_several        = "Keine einzelne Lizenz deckt die Rolle. Sie braucht %1$d Basislizenzen: %2$s.",
    key_several_more   = "Keine einzelne Lizenz deckt die Rolle. Sie braucht sicher %1$s und mindestens eine weitere Lizenz für %2$d Objekte, die diese nicht decken.",
    key_no_common      = "Keine einzelne Lizenz deckt die Rolle, und kein Objekt verlangt genau eine Lizenz. Es sind mehrere Lizenzen nötig; welche, zeigt das Blatt „%s“.",
    key_unknown        = "D365 macht zu den Objekten dieser Rolle keine Lizenzangabe.",
    key_fixing         = "Diese Bausteine legen eine Lizenz fest: %s (Tabelle unten).",
    key_fixing_part    = "%1$d für %2$s",
    key_duties         = "Aufgaben der Rolle nach benötigter Lizenz (insgesamt %1$d): %2$s.",
    key_duties_base    = "Basislizenz %d",
    key_duties_level   = "%2$s %1$d",
    key_duties_unknown = "ohne Lizenzangabe in D365 %d",
    key_objects_head     = "Von %1$d Objekten der Rolle (Menüpunkte und Datenzugriffe) brauchen %2$d eine Basislizenz",
    key_objects_part     = "%1$d nur %2$s",
    key_objects_choice   = "Bei %d davon genügt eine von mehreren Lizenzen.",
    key_objects_multiple = "%d davon brauchen mehrere Lizenzen zugleich: Keine einzelne Lizenz deckt alle Zugriffe, die die Rolle auf sie hat.",
    key_objects_none     = "Keines der %d Objekte der Rolle (Menüpunkte und Datenzugriffe) braucht eine Basislizenz.",
    key_subroles_none  = "Unterrollen der Rolle: %d. Keine braucht eine Basislizenz; der Bedarf entsteht nur durch Aufgaben und Rechte, die der Rolle direkt zugewiesen sind.",
    key_subroles_some  = "Unterrollen der Rolle: %2$d, davon mit Basislizenz: %1$d.",

    options_note = "Die genannte Lizenz deckt diese Bausteine nicht. Ob die Benutzer sie brauchen, entscheidet der Fachbereich.",
    reading_role = c(
      "Blatt „%s“: die Aufgaben, Rechte und Unterrollen, die der Rolle direkt zugewiesen sind, mit ihrer Lizenz.",
      "Blatt „%s“: jede Aufgabe der Rolle, auch die aus den Unterrollen, mit ihrer Lizenz.",
      "Blatt „%s“: welche Rechte in welcher Aufgabe stecken, mit der Lizenz je Recht.",
      "Blatt „%s“: die einzelnen Menüpunkte, die eine Basislizenz verlangen, und woher sie kommen.",
      "Blatt „%s“: jedes Objekt der Rolle mit seinem Zugriff und den Lizenzen, die es decken."
    ),
    reading_marks = "Farbig hinterlegte Zeilen brauchen eine Basislizenz. Die Spalten „Wird gebraucht?“ und „Bemerkung“ sind für Ihre Einträge.",
    reading_users = "Blätter ab „%s“: wer die Bausteine mit Basislizenz tatsächlich nutzt, mit einem Hinweis je Benutzer.",
    terms = c(
      "Aufgabe (Duty): ein Bündel von Rechten für eine Tätigkeit, zum Beispiel „Aufträge verwalten“.",
      "Recht (Privilege): der Zugriff auf einzelne Menüpunkte, lesend oder schreibend.",
      "Lizenzstufen, aufsteigend: Team Members, Operations - Activity, Basislizenz (zum Beispiel Commerce, Finance, Supply Chain Management).",
      "„Nur Commerce“: Nur diese Lizenz deckt den Baustein. „Commerce oder Finance“: Eine der genannten genügt.",
      "Eine Aufgabe braucht die Lizenz, die alle ihre Objekte abdeckt."
    ),
    limits_created     = "Erstellt am %s. In anderen Umgebungen kann die Rolle anders zusammengesetzt sein.",
    limits_database    = "Quelldatenbank: %s.",
    limits_sources     = c(
      graph = "Datenquelle: der Lizenzgraph von D365 (Tabelle LicensingSecurityObjectExplodedGraph).",
      views = "Datenquelle: die Sicherheitsobjekte und die Lizenzsichten von D365. Der Lizenzgraph (Tabelle LicensingSecurityObjectExplodedGraph) ist in dieser Datenbank leer oder fehlt."
    ),
    limits = c(
      "Die Lizenzangaben stammen aus den Lizenzdaten von D365. Microsoft kann sie mit Updates ändern.",
      "„Entfallen“ heißt: für die Benutzer, die mit einer Lizenz auskommen sollen. Wird ein Baustein aus der bestehenden Rolle entfernt, verlieren ihn alle Benutzer der Rolle.",
      "Bezeichnungen von Aufgaben und Rechten stehen so da, wie D365 sie liefert oder wie die Übersetzungstabelle sie nennt."
    ),
    limits_no_persons  = "Diese Blätter sagen nichts darüber, wer die Rolle hat oder welche Aufgaben tatsächlich genutzt werden. Sie enthalten keine Personendaten.",
    limits_persons     = "Die Blätter ab „%s“ enthalten personenbezogene Nutzungsdaten. Bitte nur an Berechtigte weitergeben.",
    limits_pseudonyms  = "Benutzerkennungen sind Pseudonyme (USER_xxxx_0001). Die echten Kennungen stehen nur in der Schlüsseldatei, die in der Quellumgebung bleibt; deanonymize_workbook() führt sie zurück.",

    columns_fixing     = c("Lizenz", "Art", "Bezeichnung", "Technischer Name", "Objekte, die nur diese Lizenz deckt"),
    columns_choice     = c("Lizenz", "Art", "Bezeichnung", "Technischer Name", "Objekte mit Basislizenz"),
    columns_options    = c("Ziel: nur diese Lizenz", "Bausteine, die entfallen müssten", "Aufgaben", "Rechte", "Unterrollen", "Welche"),
    columns_blocks     = c("Art", "Bezeichnung", "Technischer Name", "Lizenz", "Lizenzstufe", "Objekte",
                           "Objekte mit Basislizenz", "Objekte, die nur diese Lizenz deckt",
                           "Wird gebraucht? (Fachbereich)", "Bemerkung"),
    columns_duties     = c("Aufgabe", "Technischer Name", "In der Rolle", "Unterrollen", "Lizenz", "Lizenzstufe",
                           "Rechte", "Objekte", "davon mit Basislizenz",
                           "Wird gebraucht? (Fachbereich)", "Bemerkung"),
    columns_privileges = c("Aufgabe", "Aufgabe, technisch", "Recht", "Recht, technisch", "Lizenz",
                           "Lizenzstufe", "Objekte", "davon mit Basislizenz"),
    columns_objects    = c("Lizenz", "Objekt", "Typ", "Nutzung messbar", "Kommt über: Aufgabe > Recht"),
    columns_all_objects = c("Objekt", "Typ", "Zugriff", "Lizenz", "Lizenzstufe", "Gedeckt von")
  )
}

.report_user_texts_de <- function() {
  list(
    sheets_users   = c("Benutzer Überblick", "Benutzer", "Nutzung der Bausteine", "Aufgaben nach Nutzung", "Nutzung je Benutzer u. Aufgabe", "Andere Rollen"),
    users_title    = "Nutzung der Rolle durch die Benutzer",
    users_subtitle = "Wer die Bausteine mit Basislizenz tatsächlich nutzt",
    sections_users = c(
      basis    = "Datenbasis",
      meaning  = "Was die Nutzung für die Lizenzen bedeutet",
      licenses = "Lizenzen und ihre Nutzung (Anzahl Benutzer)",
      blocks   = "Nutzung je Baustein (Anzahl Benutzer)",
      reading  = "So lesen Sie die Blätter",
      limits   = "Grenzen"
    ),

    basis_users      = "Benutzer mit der Rolle: %1$d. Für %2$d von ihnen liegen Nutzungsdaten vor, für %3$d nicht.",
    basis_disabled   = "Deaktivierte Benutzer mit der Rolle, hier nicht ausgewertet: %d.",
    basis_window     = "Ihre letzten Zugriffe auf Objekte der Rolle liegen zwischen dem %1$s und dem %2$s.",
    basis_notes = c(
      "Gemessen wird, welche Formulare ein Benutzer geöffnet hat. Aktionen wie das Buchen einer Rechnung werden nicht gemessen.",
      "„Objekte, die nur diese Lizenz deckt“ binden die Rolle an diese Lizenz. Wer keines davon öffnet, ist ein Kandidat dafür, in dieser Rolle ohne die Lizenz auszukommen; wo nur wenige dieser Objekte Formulare sind, ist das nicht mehr als ein Hinweis."
    ),
    meaning_judgeable       = "%1$s: %2$d der Benutzer mit Nutzungsdaten haben Objekte geöffnet, die nur diese Lizenz deckt, %3$d nicht. %4$d von %5$d dieser Objekte sind messbar.",
    meaning_unclear         = "%1$s: %2$d der Benutzer mit Nutzungsdaten haben Objekte geöffnet, die nur diese Lizenz deckt. Für die übrigen kann die Nutzung nicht entscheiden, weil nur %3$d von %4$d dieser Objekte Formulare sind. Mit dem Fachbereich klären.",
    meaning_no_fixing       = "Kein Objekt der Rolle verlangt genau eine Lizenz; die Nutzung kann den Lizenzbedarf deshalb nicht eingrenzen.",
    meaning_no_usage        = "Ohne Nutzungsdaten lässt sich über die Nutzung der Rolle nichts sagen.",
    meaning_other_roles     = "Andere Rollen: Bei %1$d von %2$d Benutzern mit Lizenzdaten lösen auch andere Rollen Basislizenzen dieser Rolle aus. Eine Änderung nur an dieser Rolle spart dort keine Lizenz (Blatt „%3$s“).",
    meaning_no_license_data = "D365 hat für die Benutzer dieser Rolle keine Lizenzzeilen; ihre anderen Rollen ließen sich deshalb nicht prüfen.",
    meaning_duties          = "Aufgaben ohne beobachtete Nutzung: Bei %1$d der %2$d Aufgaben hat kein Benutzer ein Formular geöffnet. Bei %3$d davon besteht ein Teil mit eigener Lizenz nur aus Aktionen oder Datenzugriffen, die nicht messbar sind. Weitere %4$d Aufgaben enthalten gar kein Formular (Blatt „%5$s“).",
    user_reading = c(
      "Blatt „%s“: eine Zeile je Benutzer mit den genutzten Lizenzen und einem Hinweis.",
      "Blatt „%s“: je Benutzer und Baustein die Aufrufe und die Bewertung.",
      "Blatt „%s“: je Aufgabe, wie viele Benutzer sie nutzen. Aufgaben ohne beobachtete Nutzung stehen oben.",
      "Blatt „%s“: alle Einzelwerte zum Filtern.",
      "Blatt „%s“: die anderen Rollen eines Benutzers, die dieselben Basislizenzen auslösen."
    ),
    user_limits = c(
      "„Keine Nutzung beobachtet“ heißt: im Zeitraum der Nutzungsdaten kein Formular geöffnet. Das ist ein Hinweis, kein Beweis (Vertretung, seltene oder saisonale Tätigkeiten).",
      "Ein Baustein entfällt für einzelne Benutzer nur über eine eigene Rollenvariante. In der bestehenden Rolle entfernt, verlieren ihn alle Benutzer.",
      "Diese Blätter enthalten personenbezogene Nutzungsdaten. Bitte nur an Berechtigte weitergeben."
    ),

    columns_license_usage = c("Lizenz", "Objekte, die nur diese Lizenz deckt", "davon messbar", "Benutzer: genutzt",
                              "Benutzer: keine Nutzung beobachtet", "Benutzer: unklar", "Benutzer: keine Nutzungsdaten"),
    columns_block_summary = c("Lizenz", "Art", "Baustein", "Technischer Name",
                              "Messbare Objekte mit Basislizenz", "Benutzer: Basislizenz-Teil genutzt",
                              "Benutzer: nur andere Objekte genutzt", "Benutzer: keine Nutzung beobachtet",
                              "Benutzer: nicht messbar", "Benutzer: keine Nutzungsdaten"),
    columns_users         = c("Benutzer", "Nutzungsdaten", "Hinweis aus der Nutzung", "Genutzte Lizenzen",
                              "Lizenzen ohne beobachtete Nutzung", "Lizenzen, die die Nutzung nicht beurteilen kann", "Genutzte Aufgaben",
                              "Letzter Zugriff", "Lizenzen heute laut D365", "Dieselben Basislizenzen auch über andere Rollen",
                              "Entscheidung (Fachbereich)", "Bemerkung"),
    columns_user_blocks   = c("Benutzer", "Art", "Baustein", "Technischer Name", "Lizenz des Bausteins", "Aufrufe",
                              "davon Objekte mit Basislizenz", "Messbare Objekte mit Basislizenz",
                              "Letzter Zugriff", "Bewertung"),
    columns_duty_usage    = c("Aufgabe", "Technischer Name", "Lizenz", "Lizenzstufe", "Benutzer mit Nutzung", "Aufrufe",
                              "Letzter Zugriff", "Bewertung", "Messbare Objekte", "Wird gebraucht? (Fachbereich)", "Bemerkung"),
    columns_user_duties   = c("Benutzer", "Aufgabe", "Technischer Name", "Lizenz", "Aufrufe", "Letzter Zugriff", "Nachweis"),
    columns_other_roles   = c("Benutzer", "Lizenz", "Andere Rolle", "Andere Rolle, technisch"),

    rating_block = c(USED = "Basislizenz-Teil genutzt", PARTIAL = "nur andere Objekte geöffnet",
                     NOT_USED = "keine Nutzung beobachtet", NOT_MEASURABLE = "nicht messbar",
                     NO_DATA = "keine Nutzungsdaten"),
    rating_duty  = c(USED = "genutzt", NOT_USED = "bei keinem Benutzer Nutzung beobachtet",
                     PARTLY_MEASURABLE = "bei keinem Benutzer Nutzung beobachtet, nur teilweise messbar",
                     NOT_MEASURABLE = "nicht messbar", NO_DATA = "keine Nutzungsdaten"),
    evidence     = c(USED = "genutzt", NOT_OBSERVED = "keine Nutzung beobachtet",
                     NOT_MEASURABLE = "keine Nutzung beobachtet, nur teilweise messbar", NO_USER_TELEMETRY = "keine Nutzungsdaten"),
    hints        = c(
      NO_DATA      = "Keine Nutzungsdaten: inaktiv, oder die Kennung weicht ab. Klären.",
      NOT_OBSERVED = "Keine Nutzung beobachtet für %s: Kandidat für eine Rollenvariante ohne die Bausteine, die das verlangen.",
      UNCLEAR      = "Die Nutzung kann %s nicht beurteilen: mit dem Fachbereich klären.",
      USED         = "Genutzt: %s.",
      NONE         = "Kein Objekt der Rolle verlangt genau eine Lizenz."
    )
  )
}

# =============================================================================
# Labels built from the texts
# =============================================================================

# "A | B | C" becomes "A, B or C".
.join_alternatives <- function(skus, texts) {

  if (length(skus) < 2L) {
    return(paste(skus, collapse = ""))
  }

  sprintf(
    texts$need_or,
    paste(skus[-length(skus)], collapse = .LIST_SEPARATOR),
    skus[[length(skus)]]
  )
}

# Need as the report shows it: "Only Commerce", "Commerce or Finance",
# "Team Members".
.need_label <- function(need, is_base, texts) {

  label_one <- function(one_need, one_is_base) {
    if (one_need == .NEED_UNKNOWN)  return(texts$need_unknown)
    if (one_need == .NEED_MULTIPLE) return(texts$need_multiple)
    if (!one_is_base)               return(one_need)

    skus <- .split_skus(one_need)[[1]]
    if (length(skus) == 1L) sprintf(texts$need_only, skus) else .join_alternatives(skus, texts)
  }

  unname(mapply(label_one, as.character(need), as.logical(is_base), USE.NAMES = FALSE)) |>
    as.character()
}

.level_label <- function(need, is_base, texts) {
  dplyr::case_when(
    need == .NEED_UNKNOWN ~ texts$level_unknown,
    is_base               ~ texts$level_base,
    TRUE                  ~ as.character(need)
  )
}

# Order of rows: blocks that fix a license first, then those without a common
# license, those with a choice, the cheaper licenses and last the unknown ones.
.order_by_need <- function(need, is_base, priority, ...) {

  group <- dplyr::case_when(
    .is_fixing_need(need, is_base) ~ .NEED_GROUP_ORDER[["fixing"]],
    need == .NEED_MULTIPLE         ~ .NEED_GROUP_ORDER[["multiple"]],
    is_base                        ~ .NEED_GROUP_ORDER[["choice"]],
    need == .NEED_UNKNOWN          ~ .NEED_GROUP_ORDER[["unknown"]],
    TRUE                           ~ .NEED_GROUP_ORDER[["cheaper"]]
  )

  # among the cheaper licenses the more expensive one comes first
  within_group <- ifelse(group == .NEED_GROUP_ORDER[["cheaper"]], -priority, priority)

  order(group, within_group, need, ...)
}

.NEED_GROUP_ORDER <- c(fixing = 1, multiple = 2, choice = 3, cheaper = 4, unknown = 5)

# "A | B" as running text: "A, B".
.display_list <- function(skus) {
  gsub(.SKU_SEPARATOR, .LIST_SEPARATOR, skus, fixed = TRUE)
}

# =============================================================================
# Translation table: language of the report and names of the security objects
# =============================================================================

.TRANSLATION_COLUMNS <- c("TYPE", "IDENTIFIER", "LABEL", "LANGUAGE")

# Kind of security object behind each kind of building block.
.TRANSLATION_TYPE_OF_BLOCK <- c(Duty = "DUTY", Privilege = "PRIVILEGE", SubRole = "ROLE")

# Returns NULL without a translation table, otherwise its rows with TYPE,
# IDENTIFIER and LANGUAGE in a comparable spelling. Reading its own result
# again changes nothing.
.read_report_translations <- function(translations) {

  if (is.null(translations)) {
    return(NULL)
  }

  if (.is_single_string(translations)) {
    if (!file.exists(translations)) {
      stop("translations file not found: ", translations)
    }
    translations <- readxl::read_excel(translations, col_types = "text")
  }

  .check_required_columns(translations, .TRANSLATION_COLUMNS, "translations")

  rows <- tibble::tibble(
    TYPE       = .identifier_key(translations$TYPE),
    IDENTIFIER = .identifier_key(translations$IDENTIFIER),
    LABEL      = trimws(as.character(translations$LABEL)),
    LANGUAGE   = .language_code(translations$LANGUAGE)
  ) |>
    dplyr::filter(!is.na(IDENTIFIER), IDENTIFIER != "", !is.na(LABEL), LABEL != "")

  languages <- unique(rows$LANGUAGE)

  # The language becomes part of the file name, so it must be a plain code.
  if (length(languages) != 1L || is.na(languages) || !grepl("^[a-z]+$", languages)) {
    stop(
      "translations must name exactly one language code, such as \"de\", in the column LANGUAGE; found: ",
      if (length(languages) == 0L) "none" else paste(languages, collapse = .LIST_SEPARATOR)
    )
  }

  dplyr::distinct(rows, TYPE, IDENTIFIER, .keep_all = TRUE)
}

# "de", "DE" and "de-DE" all name German.
.language_code <- function(language) {
  sub("[-_].*$", "", tolower(trimws(as.character(language))))
}

# Language of the report texts: the one asked for; without a request that of
# the translation table when the report has texts for it, otherwise English.
.report_language <- function(translations, language = NULL) {

  if (!is.null(language)) {
    return(.check_report_language(language, translations))
  }
  if (is.null(translations)) {
    return(.REPORT_DEFAULT_LANGUAGE)
  }

  language <- translations$LANGUAGE[[1]]

  if (language %in% .report_languages()) {
    return(language)
  }

  warning(
    "The report has no texts for the language '", language, "' of the translation ",
    "table (available: ", paste(.report_languages(), collapse = .LIST_SEPARATOR), "). ",
    "The texts are English; the names from the table are used.",
    call. = FALSE
  )

  .REPORT_DEFAULT_LANGUAGE
}

# The language code of a request, checked against the texts the report has and
# against the language of the translation table.
.check_report_language <- function(language, translations = NULL) {

  code <- if (.is_single_string(language)) .language_code(language) else NA_character_

  if (!code %in% .report_languages()) {
    stop(
      "language must be one of: ", paste(.report_languages(), collapse = .LIST_SEPARATOR), ".",
      call. = FALSE
    )
  }
  if (!is.null(translations) && !identical(translations$LANGUAGE[[1]], code)) {
    stop(
      "language is '", code, "', but the translation table is in '", translations$LANGUAGE[[1]], "'.",
      call. = FALSE
    )
  }

  code
}

# Language the file name carries: that of the names in the report. A table in
# a language without texts still gives its names, and so its language.
.report_file_language <- function(translations, text_language) {
  if (is.null(translations)) text_language else translations$LANGUAGE[[1]]
}

# Translated name of each object, or the name it already has.
.translated_names <- function(names, identifiers, types, translations) {

  wanted    <- paste(types, .identifier_key(identifiers))
  available <- paste(translations$TYPE, translations$IDENTIFIER)

  dplyr::coalesce(translations$LABEL[match(wanted, available)], as.character(names))
}

# Replaces the names of duties, privileges and roles in every table of the report.
.translate_report <- function(report, translations) {

  if (is.null(translations)) {
    return(report)
  }

  rename <- function(table, name_column, id_column, types) {
    if (!is.data.frame(table) || !all(c(name_column, id_column) %in% names(table))) {
      return(table)
    }
    table[[name_column]] <- .translated_names(
      table[[name_column]], table[[id_column]], types(table), translations
    )
    table
  }

  block_type <- function(table) unname(.TRANSLATION_TYPE_OF_BLOCK[table$BLOCK_TYPE])
  duty       <- function(table) "DUTY"
  privilege  <- function(table) "PRIVILEGE"
  role       <- function(table) "ROLE"

  report$Role$NAME     <- .translated_names(report$Role$NAME, report$Role$IDENTIFIER, "ROLE", translations)
  report$Blocks        <- rename(report$Blocks, "BLOCK_NAME", "BLOCK_ID", block_type)
  report$UserBlocks    <- rename(report$UserBlocks, "BLOCK_NAME", "BLOCK_ID", block_type)
  report$Duties        <- rename(report$Duties, "DUTYNAME", "DUTYIDENTIFIER", duty)
  report$DutyUsage     <- rename(report$DutyUsage, "DUTYNAME", "DUTYIDENTIFIER", duty)
  report$UserDutyUsage <- rename(report$UserDutyUsage, "DUTYNAME", "DUTYIDENTIFIER", duty)
  report$Privileges    <- report$Privileges |>
    rename("DUTYNAME", "DUTYIDENTIFIER", duty) |>
    rename("PRIVILEGENAME", "PRIVILEGEIDENTIFIER", privilege)
  report$OtherRoles    <- rename(report$OtherRoles, "SECURITYROLENAME", "ROLEIDENTIFIER", role)

  report
}
