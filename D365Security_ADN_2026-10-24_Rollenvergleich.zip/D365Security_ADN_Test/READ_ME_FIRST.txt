D365Security - role license report, duty check and single-license plan in ADN
=============================================================================

Packed on 2026-10-24 from the branch feat/role-license-decision-tool:
commit d819533 plus check_duty_against_role(), plan_single_license_role() and
compare_role_versions() (not yet committed).


WHAT IS IN THIS FOLDER
----------------------

Playbook_Role_License_Report_Acceptance_ADN.Rmd
    The acceptance test of the report, step by step.

R\
    The 32 code files. The package does not have to be installed.

D365_Exports\
    The object lists of the role _WIBU_VERKAUF_INNENDIENST_MITARBEITER,
    exported from D365 in ADN on 2026-10-10, one file per license.

The folder holds no user data and no password. db_credentials.xlsx: use the
file on the ADN machine.

Do not source the single file check_duty_against_role.R from an earlier
download any more: it is an older version and would replace the new one.


LOADING THE CODE
----------------

1. Unzip close to the drive root, for example under Documents\RProjects.
   The folder that contains R\ is your repo_path.
2. R packages, once: install.packages(c("DBI", "odbc", "dplyr", "tibble",
   "tidyr", "lubridate", "openxlsx", "readxl", "knitr", "rmarkdown"))
3. Open the playbook in RStudio and run the chunks one by one (no "Knit"):
   "parameters", then "appendix-files" (the last chunk; it loads the 32
   files), then "connection". Skip "code-version" and "setup".


BUILDING PLAN FOR A ROLE WITH ONE LICENSE ONLY
----------------------------------------------

    plan <- plan_single_license_role(
      con         = cnn,
      source_role = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
      license     = "Supply Chain Management",
      target_role = "5CDA51EB-9559-4B27-88C4-14601045B1F0",   # or NULL for a new role
      export_path = file.path(export_folder, "Bauplan_Verkauf_Innendienst_SCM.xlsx"),
      language    = "de"
    )

Sheets: Überblick, Bauplan, Bausteine, Bleibt draußen, Legende.
In the sheet Bauplan the rows are coloured:
    no colour    only Supply Chain Management
    orange       shared with Commerce
    green        shared with Finance
    purple       shared with Commerce and Finance
    light blue   Operations - Activity is enough
    grey         Team Members or no license is enough
The column "Kommt hinein über" names the privilege to add for an object the
target role lacks. The Legende explains everything in German and English.


CHECK SINGLE DUTIES OR PRIVILEGES AGAINST ANOTHER ROLE
------------------------------------------------------

    result <- check_duty_against_role(
      con         = cnn,
      source_role = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
      duty        = c("RetailDiscountOfferMaintain", "RetailDiscountOfferView"),
      privilege   = NULL,
      target_role = "5CDA51EB-9559-4B27-88C4-14601045B1F0",
      license     = "Supply Chain Management",
      export_path = file.path(export_folder, "Pruefung_RetailDiscountOffer.xlsx"),
      language    = "de"
    )

The license name as D365 writes it: "Supply Chain Management", not "SCM".


COMPARE THE AOT ROLE WITH THE UI ROLE OF THE SAME NAME
------------------------------------------------------

One pair:

    versions <- compare_role_versions(
      con         = cnn,
      role_a      = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
      role_b      = "32B63442-1415-459D-8FF0-399780947265",
      export_path = file.path(export_folder, "Versionen_Verkauf_Innendienst.xlsx"),
      language    = "de"
    )
    versions$Check$VERDICT

Sheets: Überblick, Bausteine, Aufgaben, Rechte, Objekte, Legende. Each sheet
lists only what differs: blue = only in the AOT role, yellow = only in the UI
role, purple = both have it, but with another assignment, license or access.
The column "Davon hat die andere Version" shows whether the other role holds
the same objects in another building block.

All pairs the system has (found by name with load_role_mapping()):

    overview <- compare_role_version_pairs(
      con           = cnn,
      export_folder = file.path(export_folder, "Rollenversionen"),
      language      = "de"
    )

This writes one workbook per pair and Role_versions_overview.xlsx. A pair
that fails is listed with its reason in the column "Fehler"; the others go on.
Each pair takes about half a minute.
