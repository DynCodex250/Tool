# =============================================================================
# Texts of the workbook of check_duty_against_role()
#
# Used by export_duty_check.R. One catalogue per language with the same entries
# in the same order. "%s" stands for the license, "%d" for a number. The legend
# sheet always shows both catalogues side by side.
# =============================================================================

.duty_check_texts <- function(language = .REPORT_DEFAULT_LANGUAGE) {
  switch(
    language,
    en = .duty_check_texts_en(),
    de = .duty_check_texts_de(),
    stop("No texts for language '", language, "'.")
  )
}

.duty_check_texts_en <- function() {
  list(
    sheets     = c(overview = "Overview", gaps = "Gaps", privileges = "Privileges", not_closable = "Not closable", legend = "Legend"),
    title      = "Check of duties and privileges against the role %s",
    facts      = c("Role the duties and privileges come from", "Duties checked", "Privileges checked",
                   "Role checked against (target role)", "License the target role is to keep", "Created on"),
    none       = "none",
    no_duty    = "(no duty)",
    result     = "%1$d objects checked, %2$d gaps in the target role. Adding %3$d privileges closes %4$d of them; still open: %5$d (sheet \"Not closable\").",
    read_first = "How to read this file: sheet \"Legend\".",
    summary_columns   = c("Group", "In the role", "Only read", "Missing"),
    gap_columns       = c("Group", "State", "Object", "Access needed", "Access in the target role", "License (D365)",
                          "Duties", "Privileges", "Closed by adding"),
    privilege_columns = c("Privilege", "Name", "Duties", "Objects", "Objects the license does not cover",
                          "Gaps it contains", "Already in the target role", "Action"),
    groups  = c(NOT_COVERED = "1 not covered by %s", BASE_COVERED = "2 base license, %s covers it", BELOW_BASE = "3 Activity or lower"),
    states  = c(IN_ROLE = "in the role", ONLY_READ = "only read", MISSING = "missing"),
    actions = list(
      ADD          = c(one = "add: closes %d gap", other = "add: closes %d gaps"),
      NOT_POSSIBLE = c(one = "not possible: %d object needs another license", other = "not possible: %d objects need another license"),
      NOT_NEEDED   = c(one = "not needed: closes no gap", other = "not needed: closes no gap"),
      IN_ROLE      = c(one = "already in the role", other = "already in the role")
    ),
    yes_no = c(yes = "yes", no = "no"),
    legend = .duty_check_legend_en()
  )
}

.duty_check_legend_en <- function() {
  list(
    sheet_overview      = c("Sheet \"Overview\"", "What was checked, against which role, and the result per group."),
    sheet_gaps          = c("Sheet \"Gaps\"", "Objects the license covers that the target role lacks or can only read: what the target role would miss without the checked duties and privileges."),
    sheet_privileges    = c("Sheet \"Privileges\"", "Every privilege checked, with what to do with it in the target role (column \"Action\")."),
    sheet_not_closable  = c("Sheet \"Not closable\"", "Gaps that no privilege the license covers can close. They need a privilege of their own, built in development, or another license."),
    group               = c("Group", "Which license the object needs, seen from the license of the target role."),
    group_not_covered   = c("1 not covered by %s", "The license does not cover the object. It stays out of the target role on purpose; it is no gap."),
    group_base_covered  = c("2 base license, %s covers it", "The object needs a base license, and the license of the target role is one of those that cover it, for example \"Commerce or Supply Chain Management\". These objects are shared between the licenses."),
    group_below_base    = c("3 Activity or lower", "Team Members or Operations - Activity is enough for the object."),
    state               = c("State", "What the target role grants of the object."),
    state_in_role       = c("in the role", "The target role grants the object with at least the access needed. No gap."),
    state_only_read     = c("only read", "The target role grants the object for reading, the checked duty or privilege for writing. A gap."),
    state_missing       = c("missing", "The target role does not grant the object. A gap, unless the group is 1."),
    access              = c("Access needed / Access in the target role", "Read or Write. Empty: the target role does not grant the object."),
    license             = c("License (D365)", "The license text D365 gives for the object. \"Commerce or Supply Chain Management\" means: one of the named licenses is enough."),
    duties              = c("Duties", "The checked duties the object or privilege belongs to. \"(no duty)\": a privilege assigned to the role directly."),
    privileges          = c("Privileges", "The privileges that grant the object."),
    closed_by           = c("Closed by adding", "The privileges with the action \"add\" that close this gap. Empty: the gap is on the sheet \"Not closable\"."),
    objects             = c("Objects", "How many objects the privilege grants."),
    not_covered         = c("Objects the license does not cover", "Objects of the privilege that the license of the target role does not cover. Above 0, adding the privilege would need another license."),
    gaps                = c("Gaps it contains", "Objects of the privilege that are gaps in the target role."),
    in_role             = c("Already in the target role", "yes: the target role holds the privilege already."),
    action              = c("Action", "What to do with the privilege in the target role. One of the four values below."),
    action_add          = c("add: closes n gaps", "Add this privilege to the target role. The license covers all of its objects, so the role keeps its license, and it closes the named number of gaps."),
    action_not_possible = c("not possible: n objects need another license", "Do not add it. The privilege holds objects the license does not cover; the target role would need another license."),
    action_not_needed   = c("not needed: closes no gap", "The license covers the privilege, but the target role grants its objects already. Nothing to do."),
    action_in_role      = c("already in the role", "The target role holds the privilege. Nothing to do."),
    comparison          = c("How the check works", "Both roles come from the license graph of D365 (table LicensingSecurityObjectExplodedGraph). Objects are compared by name, with their access level, as in the role license report.")
  )
}

.duty_check_texts_de <- function() {
  list(
    sheets     = c(overview = "Überblick", gaps = "Lücken", privileges = "Rechte", not_closable = "Nicht schließbar", legend = "Legende"),
    title      = "Prüfung von Aufgaben und Rechten gegen die Rolle %s",
    facts      = c("Rolle, aus der die Aufgaben und Rechte stammen", "Geprüfte Aufgaben", "Geprüfte Rechte",
                   "Rolle, gegen die geprüft wurde (Zielrolle)", "Lizenz, bei der die Zielrolle bleiben soll", "Erstellt am"),
    none       = "keine",
    no_duty    = "(keine Aufgabe)",
    result     = "%1$d Objekte geprüft, %2$d Lücken in der Zielrolle. Die Aufnahme von %3$d Rechten schließt %4$d davon; noch offen: %5$d (Blatt „Nicht schließbar“).",
    read_first = "So lesen Sie diese Datei: Blatt „Legende“.",
    summary_columns   = c("Gruppe", "In der Rolle", "Nur lesend", "Fehlt"),
    gap_columns       = c("Gruppe", "Zustand", "Objekt", "Benötigter Zugriff", "Zugriff in der Zielrolle", "Lizenz (D365)",
                          "Aufgaben", "Rechte", "Geschlossen durch Aufnahme von"),
    privilege_columns = c("Recht", "Bezeichnung", "Aufgaben", "Objekte", "Objekte, die die Lizenz nicht deckt",
                          "Enthaltene Lücken", "Schon in der Zielrolle", "Maßnahme"),
    groups  = c(NOT_COVERED = "1 nicht von %s gedeckt", BASE_COVERED = "2 Basislizenz, %s deckt es", BELOW_BASE = "3 Activity oder niedriger"),
    states  = c(IN_ROLE = "in der Rolle", ONLY_READ = "nur lesend", MISSING = "fehlt"),
    actions = list(
      ADD          = c(one = "aufnehmen: schließt %d Lücke", other = "aufnehmen: schließt %d Lücken"),
      NOT_POSSIBLE = c(one = "nicht möglich: %d Objekt braucht eine andere Lizenz", other = "nicht möglich: %d Objekte brauchen eine andere Lizenz"),
      NOT_NEEDED   = c(one = "nicht nötig: schließt keine Lücke", other = "nicht nötig: schließt keine Lücke"),
      IN_ROLE      = c(one = "schon in der Rolle", other = "schon in der Rolle")
    ),
    yes_no = c(yes = "ja", no = "nein"),
    legend = .duty_check_legend_de()
  )
}

.duty_check_legend_de <- function() {
  list(
    sheet_overview      = c("Blatt „Überblick“", "Was geprüft wurde, gegen welche Rolle, und das Ergebnis je Gruppe."),
    sheet_gaps          = c("Blatt „Lücken“", "Objekte, die die Lizenz deckt, die die Zielrolle aber nicht hat oder nur lesen kann: was der Zielrolle ohne die geprüften Aufgaben und Rechte fehlen würde."),
    sheet_privileges    = c("Blatt „Rechte“", "Jedes geprüfte Recht und was damit in der Zielrolle zu tun ist (Spalte „Maßnahme“)."),
    sheet_not_closable  = c("Blatt „Nicht schließbar“", "Lücken, die kein von der Lizenz gedecktes Recht schließen kann. Dafür braucht es ein eigenes Recht aus der Entwicklung oder eine andere Lizenz."),
    group               = c("Gruppe", "Welche Lizenz das Objekt braucht, gesehen von der Lizenz der Zielrolle."),
    group_not_covered   = c("1 nicht von %s gedeckt", "Die Lizenz deckt das Objekt nicht. Es bleibt bewusst außerhalb der Zielrolle; das ist keine Lücke."),
    group_base_covered  = c("2 Basislizenz, %s deckt es", "Das Objekt braucht eine Basislizenz, und die Lizenz der Zielrolle ist eine der Lizenzen, die es decken, z. B. „Commerce or Supply Chain Management“. Diese Objekte sind die Schnittmenge der Lizenzen."),
    group_below_base    = c("3 Activity oder niedriger", "Für das Objekt reicht Team Members oder Operations - Activity."),
    state               = c("Zustand", "Was die Zielrolle von dem Objekt gewährt."),
    state_in_role       = c("in der Rolle", "Die Zielrolle gewährt das Objekt mindestens mit dem nötigen Zugriff. Keine Lücke."),
    state_only_read     = c("nur lesend", "Die Zielrolle gewährt das Objekt zum Lesen, die geprüfte Aufgabe oder das geprüfte Recht zum Schreiben. Eine Lücke."),
    state_missing       = c("fehlt", "Die Zielrolle gewährt das Objekt nicht. Eine Lücke, außer in Gruppe 1."),
    access              = c("Benötigter Zugriff / Zugriff in der Zielrolle", "Read (lesen) oder Write (schreiben). Leer: Die Zielrolle gewährt das Objekt nicht."),
    license             = c("Lizenz (D365)", "Der Lizenztext, den D365 für das Objekt angibt. „Commerce or Supply Chain Management“ heißt: Eine der genannten Lizenzen reicht."),
    duties              = c("Aufgaben", "Die geprüften Aufgaben, zu denen das Objekt oder Recht gehört. „(keine Aufgabe)“: ein Recht, das der Rolle direkt zugeordnet ist."),
    privileges          = c("Rechte", "Die Rechte, die das Objekt gewähren."),
    closed_by           = c("Geschlossen durch Aufnahme von", "Die Rechte mit der Maßnahme „aufnehmen“, die diese Lücke schließen. Leer: Die Lücke steht auf dem Blatt „Nicht schließbar“."),
    objects             = c("Objekte", "Wie viele Objekte das Recht gewährt."),
    not_covered         = c("Objekte, die die Lizenz nicht deckt", "Objekte des Rechts, die die Lizenz der Zielrolle nicht deckt. Größer 0: Mit dem Recht bräuchte die Rolle eine andere Lizenz."),
    gaps                = c("Enthaltene Lücken", "Objekte des Rechts, die in der Zielrolle Lücken sind."),
    in_role             = c("Schon in der Zielrolle", "ja: Die Zielrolle hat das Recht bereits."),
    action              = c("Maßnahme", "Was mit dem Recht in der Zielrolle zu tun ist. Einer der vier Werte unten."),
    action_add          = c("aufnehmen: schließt n Lücken", "Dieses Recht in die Zielrolle aufnehmen. Die Lizenz deckt alle seine Objekte, die Rolle bleibt also bei ihrer Lizenz, und es schließt die genannte Zahl an Lücken."),
    action_not_possible = c("nicht möglich: n Objekte brauchen eine andere Lizenz", "Nicht aufnehmen. Das Recht enthält Objekte, die die Lizenz nicht deckt; die Zielrolle bräuchte eine andere Lizenz."),
    action_not_needed   = c("nicht nötig: schließt keine Lücke", "Die Lizenz deckt das Recht, aber die Zielrolle gewährt seine Objekte schon. Nichts zu tun."),
    action_in_role      = c("schon in der Rolle", "Die Zielrolle hat das Recht. Nichts zu tun."),
    comparison          = c("So funktioniert die Prüfung", "Beide Rollen stammen aus dem Lizenzgraphen von D365 (Tabelle LicensingSecurityObjectExplodedGraph). Objekte werden über ihren Namen und ihren Zugriff verglichen, wie im Rollen-Lizenzbericht.")
  )
}
