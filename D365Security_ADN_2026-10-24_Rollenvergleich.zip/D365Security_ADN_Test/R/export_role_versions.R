# =============================================================================
# Workbooks of compare_role_versions() and compare_role_version_pairs()
#
# One workbook per comparison: Overview, Building blocks, Duties, Privileges,
# Objects and Legend; the rows are coloured by side. One overview workbook for
# all pairs. The legend shows English and German side by side.
# =============================================================================

.VERSION_FILLS <- c(ONLY_A = "#DDEBF7", ONLY_B = "#FFF2CC", ASSIGNMENT = "#E4DFEC", LICENSE = "#E4DFEC", ACCESS = "#E4DFEC")
.VERSION_PAIR_FILLS <- c(A_IN_B = "#FFF2CC", B_IN_A = "#DDEBF7", DIFFERENT = "#E4DFEC")

.VERSION_WIDTHS <- list(
  blocks     = c(28, 12, 44, 50, 36, 10, 20),
  duties     = c(28, 44, 50, 22, 22, 36, 36),
  privileges = c(28, 44, 50, 40, 36, 10, 20),
  objects    = c(28, 44, 18, 18, 18, 36, 36)
)
.VERSION_PAIR_WIDTHS <- c(36, 40, 40, 40, 22, 14, 14, 14, 14, 14, 14, 18, 40, 40, 50, 50)

# The names of the two versions: by their kind, or A and B when both are of one kind.
.version_names <- function(check, texts) {
  if (identical(check$KIND_A, check$KIND_B)) {
    return(c(a = texts$kinds[["A"]], b = texts$kinds[["B"]]))
  }
  c(a = texts$kinds[[check$KIND_A]], b = texts$kinds[[check$KIND_B]])
}

.version_tokens <- function(text, names) {
  gsub("{b}", names[["b"]], gsub("{a}", names[["a"]], text, fixed = TRUE), fixed = TRUE)
}

.version_need_label <- function(need, is_base, texts) {

  label <- rep(NA_character_, length(need))
  known <- !is.na(need)
  if (any(known)) {
    label[known] <- .need_label(need[known], is_base[known], texts)
  }

  label
}

.export_role_versions <- function(result, export_path, language) {

  texts         <- .version_texts(language)
  version_names <- .version_names(result$Check, texts)
  workbook      <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  header        <- openxlsx::createStyle(textDecoration = "bold", fgFill = "#DDEBF7", border = "bottom", wrapText = TRUE)
  tables        <- .version_sheets(result, texts, .report_texts(language), version_names)
  sources       <- c(blocks = "Blocks", duties = "Duties", privileges = "Privileges", objects = "Objects")

  .add_version_overview(workbook, result, texts, version_names, header)
  for (sheet in names(tables)) {
    widths <- .VERSION_WIDTHS[[sheet]]
    .add_duty_check_table(workbook, texts$sheets[[sheet]], tables[[sheet]], header, widths)
    .color_rows(workbook, texts$sheets[[sheet]], unname(.VERSION_FILLS[result[[sources[[sheet]]]]$SIDE]), seq_along(widths))
  }
  .add_duty_check_table(workbook, texts$sheets[["legend"]], .version_legend(result$Check), header,
                        .DUTY_CHECK_LEGEND_WIDTHS, wrap = TRUE)

  if (!dir.exists(dirname(export_path))) {
    dir.create(dirname(export_path), recursive = TRUE)
  }
  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)

  invisible(export_path)
}

.add_version_overview <- function(workbook, result, texts, version_names, header) {

  sheet    <- texts$sheets[["overview"]]
  check    <- result$Check
  licenses <- result$Licenses
  facts    <- data.frame(
    label = .version_tokens(texts$facts, version_names),
    value = c(
      paste0(check$ROLE_A, " (", check$NAME_A, ")"), paste0(check$ROLE_B, " (", check$NAME_B, ")"),
      licenses$LICENSES[[1]], licenses$LICENSES[[2]],
      .version_tokens(texts$verdicts[[check$VERDICT]], version_names), format(check$CREATED, "%Y-%m-%d")
    ),
    stringsAsFactors = FALSE
  )
  summary <- data.frame(
    unname(texts$items[result$Summary$ITEM]), result$Summary$A, result$Summary$B,
    result$Summary$ONLY_A, result$Summary$ONLY_B, result$Summary$DIFFERENT,
    stringsAsFactors = FALSE
  )
  names(summary) <- .version_tokens(texts$summary_columns, version_names)

  openxlsx::addWorksheet(workbook, sheet)
  openxlsx::writeData(workbook, sheet, texts$title, startRow = 1L)
  openxlsx::addStyle(workbook, sheet, openxlsx::createStyle(textDecoration = "bold", fontSize = 13), rows = 1L, cols = 1L)
  openxlsx::writeData(workbook, sheet, facts, startRow = 3L, colNames = FALSE)
  openxlsx::writeData(workbook, sheet, texts$read_first, startRow = nrow(facts) + 4L)
  openxlsx::writeData(workbook, sheet, summary, startRow = nrow(facts) + 6L, headerStyle = header)
  openxlsx::setColWidths(workbook, sheet, cols = 1:6, widths = c(36, 70, 18, 18, 18, 18))

  invisible(workbook)
}

.version_sheets <- function(result, texts, report_texts, version_names) {

  side <- function(table) .version_tokens(unname(texts$sides[table$SIDE]), version_names)
  need <- function(need, is_base) .version_need_label(need, is_base, report_texts)
  sheet <- function(columns, ...) {
    table <- data.frame(..., stringsAsFactors = FALSE)
    names(table) <- .version_tokens(columns, version_names)
    table
  }
  blocks <- result$Blocks; duties <- result$Duties; privileges <- result$Privileges; objects <- result$Objects

  list(
    blocks = sheet(texts$block_columns, side(blocks), unname(texts$block_kinds[blocks$BLOCK_TYPE]), blocks$BLOCK_ID,
                   blocks$BLOCK_NAME, need(blocks$NEED, blocks$IS_BASE), blocks$OBJECTS, blocks$IN_OTHER),
    duties = sheet(texts$duty_columns, side(duties), duties$DUTY, duties$NAME,
                   unname(texts$assignments[duties$ASSIGNMENT_A]), unname(texts$assignments[duties$ASSIGNMENT_B]),
                   need(duties$NEED_A, duties$IS_BASE_A), need(duties$NEED_B, duties$IS_BASE_B)),
    privileges = sheet(texts$privilege_columns, side(privileges), privileges$PRIVILEGE, privileges$NAME, privileges$DUTIES,
                       need(privileges$NEED, privileges$IS_BASE), privileges$OBJECTS, privileges$IN_OTHER),
    objects = sheet(texts$object_columns, side(objects), objects$OBJECT, objects$TYPE,
                    .access_label(objects$ACCESS_A), .access_label(objects$ACCESS_B),
                    need(objects$NEED_A, objects$IS_BASE_A), need(objects$NEED_B, objects$IS_BASE_B))
  )
}

# Every entry of the legend in English and German, side by side.
.version_legend <- function(check) {

  part <- function(texts, position) {
    .version_tokens(vapply(texts$legend, `[[`, character(1), position, USE.NAMES = FALSE), .version_names(check, texts))
  }
  english <- .version_texts("en")
  german  <- .version_texts("de")

  data.frame(
    Term = part(english, 1L), Meaning = part(english, 2L),
    Begriff = part(german, 1L), Bedeutung = part(german, 2L),
    stringsAsFactors = FALSE
  )
}

.export_version_overview <- function(overview, export_path, language) {

  texts    <- .version_texts(language)
  workbook <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  header   <- openxlsx::createStyle(textDecoration = "bold", fgFill = "#DDEBF7", border = "bottom", wrapText = TRUE)
  table    <- as.data.frame(overview, stringsAsFactors = FALSE)
  table$VERDICT <- unname(texts$pair_verdicts[overview$VERDICT])
  names(table)  <- texts$pair_columns

  .add_duty_check_table(workbook, texts$sheets[["overview"]], table, header, .VERSION_PAIR_WIDTHS)
  .color_rows(workbook, texts$sheets[["overview"]], unname(.VERSION_PAIR_FILLS[overview$VERDICT]), seq_along(.VERSION_PAIR_WIDTHS))
  .add_duty_check_table(workbook, texts$sheets[["legend"]], .version_legend(list(KIND_A = "AOT", KIND_B = "UI")),
                        header, .DUTY_CHECK_LEGEND_WIDTHS, wrap = TRUE)

  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)

  invisible(export_path)
}
