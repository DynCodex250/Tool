# =============================================================================
# Workbook of plan_single_license_role()
#
# Five sheets: Overview, Building plan, Building blocks, Stays outside and
# Legend. The rows of the plan, of the overview table and of the legend are
# coloured by category; the objects only the license covers have no colour.
# =============================================================================

# Colour per other license that shares an object, and per category below a
# base license.
.PLAN_FILLS <- c(
  "Commerce"                = "#FCE4D6",
  "Finance"                 = "#E2EFDA",
  "Supply Chain Management" = "#FFF2CC",
  OTHER                     = "#DDF2F0",
  SEVERAL                   = "#E4DFEC",
  ACTIVITY                  = "#DDEBF7",
  TEAM_MEMBERS              = "#EDEDED"
)

.PLAN_WIDTHS         <- c(40, 42, 18, 16, 42, 18, 46, 40, 46, 44)
.PLAN_BLOCK_WIDTHS   <- c(12, 46, 52, 10, 20, 18, 46)
.PLAN_OUTSIDE_WIDTHS <- c(42, 18, 16, 42, 40, 46, 46, 18)

# Fill colour per row: NA for the objects only the license covers.
.plan_fill <- function(category, shared_with) {

  vapply(seq_along(category), function(i) {
    others <- strsplit(shared_with[[i]], .LIST_SEPARATOR, fixed = TRUE)[[1]]
    switch(
      category[[i]],
      ACTIVITY     = .PLAN_FILLS[["ACTIVITY"]],
      TEAM_MEMBERS = .PLAN_FILLS[["TEAM_MEMBERS"]],
      SHARED       = if (length(others) > 1L) {
        .PLAN_FILLS[["SEVERAL"]]
      } else if (others %in% names(.PLAN_FILLS)) {
        .PLAN_FILLS[[others]]
      } else {
        .PLAN_FILLS[["OTHER"]]
      },
      NA_character_
    )
  }, character(1))
}

.export_single_license_plan <- function(result, export_path, language) {

  texts      <- .plan_texts(language)
  has_target <- !is.null(result$Check$TARGET_ROLE)
  workbook   <- openxlsx::createWorkbook(creator = .WORKBOOK_CREATOR)
  header     <- openxlsx::createStyle(textDecoration = "bold", fgFill = "#DDEBF7", border = "bottom", wrapText = TRUE)
  plan_sheet <- texts$sheets[["plan"]]
  legend     <- .plan_legend(result)

  .add_plan_overview(workbook, result, texts, header)
  .add_duty_check_table(workbook, plan_sheet, .plan_sheet(result$Plan, result$Check$LICENSE, texts), header, .PLAN_WIDTHS)
  .color_rows(workbook, plan_sheet, .plan_fill(result$Plan$CATEGORY, result$Plan$SHARED_WITH), seq_along(.PLAN_WIDTHS))
  .add_duty_check_table(workbook, texts$sheets[["blocks"]], .plan_blocks_sheet(result, has_target, texts), header, .PLAN_BLOCK_WIDTHS)
  .add_duty_check_table(workbook, texts$sheets[["outside"]], .plan_outside_sheet(result$Outside, has_target, texts),
                        header, .PLAN_OUTSIDE_WIDTHS)
  .add_duty_check_table(workbook, texts$sheets[["legend"]], legend$table, header, .DUTY_CHECK_LEGEND_WIDTHS, wrap = TRUE)
  .color_rows(workbook, texts$sheets[["legend"]], legend$fills, seq_along(.DUTY_CHECK_LEGEND_WIDTHS))

  if (!dir.exists(dirname(export_path))) {
    dir.create(dirname(export_path), recursive = TRUE)
  }
  openxlsx::saveWorkbook(workbook, export_path, overwrite = TRUE)

  invisible(export_path)
}

# Colours the data rows; the first of them is at first_row.
.color_rows <- function(workbook, sheet, fills, columns, first_row = 2L) {

  for (fill in unique(fills[!is.na(fills)])) {
    openxlsx::addStyle(
      workbook, sheet, openxlsx::createStyle(fgFill = fill),
      rows = which(fills == fill) + first_row - 1L, cols = columns, gridExpand = TRUE, stack = TRUE
    )
  }

  invisible(workbook)
}

.plan_fill_tokens <- function(text, license, others = rep("", length(text)), source = "") {

  text <- gsub("{license}", license, text, fixed = TRUE)
  text <- gsub("{source}", source, text, fixed = TRUE)

  vapply(seq_along(text), function(i) gsub("{others}", others[[i]], text[[i]], fixed = TRUE), character(1))
}

.plan_category_label <- function(category, shared_with, license, texts) {
  .plan_fill_tokens(unname(texts$categories[category]), license, shared_with)
}

.add_plan_overview <- function(workbook, result, texts, header) {

  sheet <- texts$sheets[["overview"]]
  check <- result$Check
  facts <- data.frame(
    label = texts$facts,
    value = c(check$SOURCE_ROLE, if (is.null(check$TARGET_ROLE)) texts$new_role else check$TARGET_ROLE,
              check$LICENSE, format(check$CREATED, "%Y-%m-%d")),
    stringsAsFactors = FALSE
  )
  lines       <- .plan_result_lines(result, texts)
  summary     <- .plan_summary_sheet(result, texts)
  lines_row   <- nrow(facts) + 4L
  summary_row <- lines_row + length(lines) + 1L

  openxlsx::addWorksheet(workbook, sheet)
  openxlsx::writeData(workbook, sheet, .plan_fill_tokens(texts$title, check$LICENSE, source = check$SOURCE_ROLE), startRow = 1L)
  openxlsx::addStyle(workbook, sheet, openxlsx::createStyle(textDecoration = "bold", fontSize = 13), rows = 1L, cols = 1L)
  openxlsx::writeData(workbook, sheet, facts, startRow = 3L, colNames = FALSE)
  openxlsx::writeData(workbook, sheet, lines, startRow = lines_row)
  openxlsx::writeData(workbook, sheet, summary, startRow = summary_row, headerStyle = header)
  .color_rows(workbook, sheet, .plan_fill(result$Summary$CATEGORY, result$Summary$SHARED_WITH), seq_len(ncol(summary)),
              first_row = summary_row + 1L)
  openxlsx::setColWidths(workbook, sheet, cols = 1:5, widths = c(46, 60, 14, 14, 14))

  invisible(workbook)
}

.plan_result_lines <- function(result, texts) {

  plan     <- result$Plan
  check    <- result$Check
  adds     <- sum(result$Privileges$ACTION == "ADD")
  separate <- sum(plan$NOTE %in% "NEW_PRIVILEGE")

  second <- if (is.null(check$TARGET_ROLE)) {
    sprintf(texts$result_new, adds, separate)
  } else {
    sprintf(texts$result_target, sum(plan$STATE %in% "IN_ROLE"), sum(plan$STATE %in% "ONLY_READ"),
            sum(plan$STATE %in% "MISSING"), adds, separate)
  }

  c(sprintf(texts$result, nrow(plan), check$LICENSE, nrow(result$Outside)), second, texts$read_first)
}

# Without a target role only the number of objects per category means something.
.plan_summary_sheet <- function(result, texts) {

  summary <- result$Summary
  table   <- data.frame(
    .plan_category_label(summary$CATEGORY, summary$SHARED_WITH, result$Check$LICENSE, texts),
    summary$OBJECTS, summary$IN_ROLE, summary$ONLY_READ, summary$MISSING,
    stringsAsFactors = FALSE
  )
  names(table) <- texts$summary_columns

  if (is.null(result$Check$TARGET_ROLE)) table[1:2] else table
}

.plan_sheet <- function(plan, license, texts) {

  table <- data.frame(
    .plan_category_label(plan$CATEGORY, plan$SHARED_WITH, license, texts),
    plan$OBJECT,
    plan$TYPE,
    .access_label(plan$ACCESS),
    plan$LICENSE,
    unname(texts$states[plan$STATE]),
    plan$COMES_IN_VIA,
    .duty_check_no_duty(plan$DUTIES, texts),
    plan$PRIVILEGES,
    unname(texts$notes[plan$NOTE]),
    stringsAsFactors = FALSE
  )
  names(table) <- texts$plan_columns

  table
}

.plan_blocks_sheet <- function(result, has_target, texts) {

  duties     <- result$Duties
  privileges <- result$Privileges
  in_role    <- c(duties$IN_ROLE_ALREADY, privileges$IN_ROLE_ALREADY)

  table <- data.frame(
    c(rep(texts$kinds[["DUTY"]], nrow(duties)), rep(texts$kinds[["PRIVILEGE"]], nrow(privileges))),
    c(duties$DUTY, privileges$PRIVILEGE),
    c(duties$NAME, privileges$NAME),
    c(duties$OBJECTS, privileges$OBJECTS),
    c(duties$NOT_COVERED, privileges$NOT_COVERED),
    if (has_target) ifelse(in_role, texts$yes_no[["yes"]], texts$yes_no[["no"]]) else rep("", length(in_role)),
    c(unname(texts$fits[duties$FIT]), .duty_check_action_label(privileges, texts)),
    stringsAsFactors = FALSE
  )
  names(table) <- texts$block_columns

  table
}

.plan_outside_sheet <- function(outside, has_target, texts) {

  target_reads <- if (has_target) {
    ifelse(is.na(outside$TARGET_ACCESS), texts$yes_no[["no"]], texts$yes_no[["yes"]])
  } else {
    rep("", nrow(outside))
  }

  table <- data.frame(
    outside$OBJECT,
    outside$TYPE,
    .access_label(outside$ACCESS),
    outside$LICENSE,
    .duty_check_no_duty(outside$DUTIES, texts),
    outside$PRIVILEGES,
    outside$READ_VIA,
    target_reads,
    stringsAsFactors = FALSE
  )
  names(table) <- texts$outside_columns

  table
}

# Legend rows in English and German side by side: first the categories of this
# plan with their colours, then every sheet, column and value.
.plan_legend <- function(result) {

  license <- result$Check$LICENSE
  english <- .plan_texts("en")
  german  <- .plan_texts("de")

  shared   <- result$Summary$SHARED_WITH[result$Summary$CATEGORY == "SHARED"]
  category <- c("ONLY", rep("SHARED", length(shared)), "ACTIVITY", "TEAM_MEMBERS", "OUTSIDE")
  others   <- c("", shared, "", "", "")
  meaning  <- function(texts) .plan_fill_tokens(unname(texts$category_meanings[category]), license, others)
  part     <- function(texts, position) {
    .plan_fill_tokens(vapply(texts$legend, `[[`, character(1), position, USE.NAMES = FALSE), license)
  }

  table <- data.frame(
    Term      = c(.plan_category_label(category, others, license, english), part(english, 1L)),
    Meaning   = c(meaning(english), part(english, 2L)),
    Begriff   = c(.plan_category_label(category, others, license, german), part(german, 1L)),
    Bedeutung = c(meaning(german), part(german, 2L)),
    stringsAsFactors = FALSE
  )

  list(table = table, fills = c(.plan_fill(category, others), rep(NA_character_, length(english$legend))))
}
