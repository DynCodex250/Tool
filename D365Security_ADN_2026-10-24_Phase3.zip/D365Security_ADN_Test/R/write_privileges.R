#' Privileges in ein D365FO Security XML schreiben
#'
#' Schreibt direkt zugewiesene Privileges in die XML-Struktur eines
#' D365FO Security-Objekts.
#'
#' Die Funktion erzeugt unterhalb des übergebenen XML-Knotens
#' einen `Privileges`-Container und fügt für jedes Privilege einen
#' `AxSecurityPrivilegeReference`-Knoten hinzu.
#'
#' Die erzeugte XML-Struktur entspricht dem von D365FO
#' verwendeten Security-Metadatenformat für referenzierte
#' Security Privileges.
#'
#' Beispiel:
#'
#' \preformatted{
#' <Privileges>
#'   <AxSecurityPrivilegeReference>
#'     <Name>CustTableMaintain</Name>
#'   </AxSecurityPrivilegeReference>
#'
#'   <AxSecurityPrivilegeReference>
#'     <Name>SalesTableView</Name>
#'   </AxSecurityPrivilegeReference>
#' </Privileges>
#' }
#'
#' @param parent_node XML-Knoten, unterhalb dessen der
#'   `Privileges`-Container erzeugt werden soll.
#'
#' @param privileges Character-Vektor mit den Namen der
#'   referenzierten D365FO Security Privileges.
#'
#' @return XML-Knoten vom Typ `Privileges`.
#'
#' Bei leerem `privileges`-Vektor wird lediglich ein leerer
#' `Privileges`-Knoten erzeugt und zurückgegeben.
#'
#' @details
#' Die Funktion verändert die übergebene XML-Struktur direkt.
#'
#' Für jedes Privilege wird ein XML-Knoten der Form
#' `AxSecurityPrivilegeReference` erzeugt.
#'
#' Die Funktion wird beim Generieren von D365FO Security-Rollen
#' verwendet, innerhalb von `create_role_xml()` und
#' `create_d365fo_role_xml()`.
#'
#' @examples
#' \dontrun{
#'
#' root <- xml2::xml_new_root(
#'   "AxSecurityRole"
#' )
#'
#' write_privileges(
#'   parent_node = root,
#'   privileges = c(
#'     "CustTableMaintain",
#'     "SalesTableView"
#'   )
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{write_duties}}
#' \code{\link{write_subroles}}
#'
#' @export
write_privileges <- function(
    parent_node,
    privileges
) {

  # ================================
  # PRIVILEGE-CONTAINER ERZEUGEN
  # ================================

  privileges_node <- xml2::xml_add_child(
    parent_node,
    "Privileges"
  )

  # ================================
  # LEEREN CONTAINER ZURÜCKGEBEN
  # ================================

  if (length(privileges) == 0) {

    return(privileges_node)

  }

  # ================================
  # PRIVILEGES HINZUFÜGEN
  # ================================

  for (privilege in privileges) {

    privilege_ref <- xml2::xml_add_child(
      privileges_node,
      "AxSecurityPrivilegeReference"
    )

    xml2::xml_add_child(
      privilege_ref,
      "Name",
      privilege
    )

  }

  # ================================
  # XML-KNOTEN ZURÜCKGEBEN
  # ================================

  return(privileges_node)

}
