#' Export a role from the database as role XML
#'
#' Reads a role from the table \code{UserSecGovRelatedObjects} and writes it
#' as an AOT role file (\code{AxSecurityRole}), the format of a Visual Studio
#' project, and packs it into a zip. The role keeps its structure: its own
#' duties, privileges, sub-roles and direct access permissions; what comes
#' through a sub-role stays in the sub-role.
#'
#' @details
#'
#' **Names.** The role and its sub-roles are written in the spelling of the
#' table \code{SECURITYROLE}; \code{UserSecGovRelatedObjects} holds them in
#' capitals. When \code{SECURITYROLE} cannot be read, the function warns and
#' keeps the capitals; D365 does not tell the two apart.
#'
#' **Files.** The XML goes to \code{<output_folder>/AxSecurityRole/<name>.xml},
#' the folder layout of a model. The zip \code{<output_folder>/<name>.zip}
#' holds that folder; unpacked into a model folder, Visual Studio finds the
#' role. An existing file of the same name is replaced.
#'
#' **Sub-roles of the user interface.** A role created in the user interface
#' (its identifier is a GUID) exists only in the database. The function warns
#' when such a role is a sub-role: Visual Studio cannot resolve it.
#'
#' **Import in the browser.** The security configuration of D365
#' (System administration > Security > Security configuration) imports its
#' own export format. This function does not write that format yet.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param role_identifier
#' AOT name or GUID of the role.
#'
#' @param output_folder
#' Folder for the XML and the zip; it is created when missing.
#'
#' @param name
#' AOT name of the written role, for a copy under another name. \code{NULL} =
#' the name of the role. No whitespace.
#'
#' @param label
#' Label of the written role. \code{NULL} = the label of the role.
#'
#' @param zip
#' \code{TRUE} = also write the zip.
#'
#' @return
#' Invisibly a list with \code{xml} (path of the XML), \code{zip} (path of the
#' zip, \code{NA} without zip) and \code{role} (the role as
#' \code{\link{convert_sql_to_security_role}} returns it).
#'
#' @examples
#' \dontrun{
#'
#' result <- export_role_xml(
#'   cnn,
#'   role_identifier = "_WIBU_VERKAUF_INNENDIENST_LEITUNG",
#'   output_folder   = "Output/Roles"
#' )
#' result$zip
#'
#' # The role of the user interface as a copy under an AOT name
#' export_role_xml(
#'   cnn, "E5BD996C-D492-4533-B562-F207DCC0B214", "Output/Roles",
#'   name = "_WIBU_Verkauf_Innendienst_Leitung_UI", label = "_WIBU Verkauf Innendienst Leitung (UI)"
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{load_sql_security_role_objects_detailed}}
#' \code{\link{convert_sql_to_security_role}}
#' \code{\link{create_d365fo_role_xml}}
#'
#' @export
export_role_xml <- function(con, role_identifier, output_folder, name = NULL, label = NULL, zip = TRUE) {

  if (!.is_single_string(role_identifier)) {
    stop("role_identifier must name one role: the AOT name, or the GUID of a role created in the user interface.",
         call. = FALSE)
  }
  if (!.is_single_string(output_folder)) {
    stop("output_folder must be the path of one folder.", call. = FALSE)
  }
  if (!is.null(name)) .check_aot_name(name)

  rows <- load_sql_security_role_objects_detailed(con, role_identifier)
  if (nrow(rows) == 0L) {
    stop("No security objects found for role '", role_identifier, "' in UserSecGovRelatedObjects.", call. = FALSE)
  }

  role <- .with_stored_role_names(con, convert_sql_to_security_role(rows))
  role$role_name  <- if (is.null(name)) role$role_name else name
  role$role_label <- if (is.null(label)) role$role_label else label
  .check_aot_name(role$role_name)
  .warn_about_ui_subroles(role$subroles)

  xml_file <- file.path(.AOT_ROLE_FOLDER, paste0(role$role_name, ".xml"))
  xml_path <- file.path(output_folder, xml_file)
  dir.create(dirname(xml_path), recursive = TRUE, showWarnings = FALSE)
  create_d365fo_role_xml(role, xml_path)

  zip_path <- if (isTRUE(zip)) .zip_metadata(output_folder, xml_file, role$role_name) else NA_character_

  message(sprintf(
    "Role %s written: %d duties, %d privileges, %d sub-roles, %d direct access permissions.",
    role$role_name, length(role$duties), length(role$privileges), length(role$subroles),
    sum(role$direct_access_permissions$Ebene == "Entity")
  ))

  invisible(list(xml = xml_path, zip = zip_path, role = role))
}

.AOT_ROLE_FOLDER      <- "AxSecurityRole"
.AOT_PRIVILEGE_FOLDER <- "AxSecurityPrivilege"

# Letters, digits, underscores, and the hyphens of a GUID: the name becomes a file
# name, so a dot or slash could leave the output folder.
.check_aot_name <- function(name) {
  if (!.is_single_string(name) || !grepl("^[A-Za-z0-9_][A-Za-z0-9_-]*$", name)) {
    stop("name must be an AOT name of letters, digits and underscores, without whitespace, dots or slashes: '",
         paste(name, collapse = "', '"), "'.", call. = FALSE)
  }
  invisible(name)
}

# A role created in the user interface exists only in the database, not in the
# AOT: a Visual Studio project cannot resolve it as a sub-role.
.warn_about_ui_subroles <- function(subroles) {
  ui_roles <- subroles[is_guid_name(subroles)]
  if (length(ui_roles) > 0L) {
    warning(
      "Sub-roles created in the user interface: ", paste(ui_roles, collapse = ", "),
      ". Visual Studio cannot resolve them; create them as AOT roles first, or import the role in the browser.",
      call. = FALSE
    )
  }
  invisible(ui_roles)
}

# The role and its sub-roles in the spelling of SECURITYROLE.
.with_stored_role_names <- function(con, role) {

  stored <- tryCatch(
    .load_stored_role_names(con, c(role$role_name, role$subroles)),
    error = function(e) {
      warning("SECURITYROLE could not be read, the role names stay as UserSecGovRelatedObjects writes them: ",
              .without_sql_statement(conditionMessage(e)), call. = FALSE)
      NULL
    }
  )
  if (is.null(stored) || nrow(stored) == 0L) {
    return(role)
  }

  spelled <- function(x) {
    found <- stored$AOTNAME[match(.identifier_key(x), .identifier_key(stored$AOTNAME))]
    dplyr::coalesce(found, x)
  }
  role$role_name <- spelled(role$role_name)
  role$subroles  <- spelled(role$subroles)
  role
}

.load_stored_role_names <- function(con, identifiers) {
  identifiers  <- unique(identifiers[!is.na(identifiers)])
  placeholders <- paste(rep("?", length(identifiers)), collapse = ", ")
  DBI::dbGetQuery(
    con,
    paste0("SELECT AOTNAME, NAME FROM SECURITYROLE WHERE AOTNAME IN (", placeholders, ")"),
    params = as.list(identifiers)
  )
}

# Packs files of a folder into <folder>/<name>.zip; the paths inside the zip
# are the paths below the folder.
.zip_metadata <- function(folder, files, name) {
  folder   <- normalizePath(folder, winslash = "/", mustWork = TRUE)
  zip_path <- file.path(folder, paste0(name, ".zip"))
  if (file.exists(zip_path) && !file.remove(zip_path)) {
    stop("The zip '", zip_path, "' cannot be replaced; it may be open in another program.", call. = FALSE)
  }
  zip::zip(zipfile = zip_path, files = files, root = folder, mode = "mirror")
  zip_path
}
