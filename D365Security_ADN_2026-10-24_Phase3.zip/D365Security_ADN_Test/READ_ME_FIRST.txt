D365Security - phase 3 in ADN: analysis of a role, role XML, roles per license
==============================================================================

Packed on 2026-10-24 from the branch feat/role-license-decision-tool
(not yet committed). New since D365Security_ADN_2026-10-24_Rollenpaare.zip:

  - Analyse_Rolle_Lizenzen.Rmd: the analysis of a role with nine questions,
    as your version with code and as a Word file for the business department.
  - export_role_xml(): a role from the database as role XML and zip.
  - build_license_roles(): one role per license from what the users use.
  - Playbook: new steps 10 and 11; "Result" is now step 12.
  - 11 more code files: 43 in all.


WHAT IS IN THIS FOLDER
----------------------

Playbook_Role_License_Report_Acceptance_ADN.Rmd
    The acceptance test, step by step (run chunk by chunk).

Analyse_Rolle_Lizenzen.Rmd
    The analysis of the role (German). One file, two versions.

R\
    The 43 code files. The package does not have to be installed.

D365_Exports\
    The object lists of the role _WIBU_VERKAUF_INNENDIENST_MITARBEITER,
    exported from D365 in ADN on 2026-10-10, one file per license.

The folder holds no user data and no password. db_credentials.xlsx: use the
file on the ADN machine.


LOADING THE CODE (playbook)
---------------------------

1. Unzip close to the drive root, for example under Documents\RProjects.
   The folder that contains R\ is your repo_path.
2. R packages, once: install.packages(c("DBI", "odbc", "dplyr", "tibble",
   "tidyr", "lubridate", "openxlsx", "readxl", "knitr", "rmarkdown", "zip"))
3. Open the playbook in RStudio and run the chunks one by one (no "Knit"):
   "parameters", then "appendix-files" (the last chunk; it loads the 43
   files), then "connection". Skip "code-version" and "setup".
4. Then step 2 (telemetry, it fills `usage`), and steps 9 to 11.


THE ANALYSIS OF THE ROLE
------------------------

The analysis answers nine questions about one role, by default
_WIBU_VERKAUF_INNENDIENST_MITARBEITER:

  1. Which licenses does the role need, and why?
  2. What would have to go so that one license is enough?
  3. Who uses the parts that need a base license?
  4. Does changing only this role save anything (other roles, UI version)?
  5. AOT role against the UI role of the same name.
  6. The role with one license only (building plan).
  7. What is used, what never?
  8. Which roles per license come out of the usage?
  9. Which license would each user need afterwards?

Users appear only as counts. In a fresh R session in RStudio:

    folder <- "C:/Users/CKAM/Documents/RProjects/D365Security_ADN_Test"   # where you unzipped

    # Your version, with code; the workbooks go to export_ordner
    rmarkdown::render(
      file.path(folder, "Analyse_Rolle_Lizenzen.Rmd"),
      params = list(code_laden = "dateien", repo_path = folder,
                    export_ordner = "C:/Users/CKAM/Documents/RProjects/Output/Analyse_Rolle"),
      output_file = "Analyse_Verkauf_Innendienst.docx"
    )

    # The version for the business department: Word, no code, no files
    rmarkdown::render(
      file.path(folder, "Analyse_Rolle_Lizenzen.Rmd"),
      params = list(fassung = "fachbereich", code_laden = "dateien", repo_path = folder),
      output_file = "Analyse_Verkauf_Innendienst_Fachbereich.docx"
    )

Other parameters (all in the header of the Rmd): rolle, ui_rolle, ziel_lizenz,
ziel_rolle, umgebung, cred_path, telemetrie (empty = load from Insights with
D365Licensing). Each render runs the whole analysis; that takes a few minutes.

Your version writes to export_ordner: the license report, the building plan,
the comparison of the two role versions, and in "Lizenzrollen" the roles per
license as XML, zip and workbook. These workbooks hold user ids; do not pass
them on. The Word file for the business department holds counts only.


ROLE XML FROM THE DATABASE
--------------------------

    result <- export_role_xml(cnn, "_WIBU_VERKAUF_INNENDIENST_LEITUNG",
                              output_folder = file.path(export_folder, "Rollen_XML"))
    result$zip

Writes AxSecurityRole\<name>.xml and <name>.zip: the role with its own
duties, privileges, sub-roles and direct access permissions, in the format of
a Visual Studio project. name = "..." and label = "..." write a copy under
another name. A warning names sub-roles created in the user interface:
Visual Studio cannot resolve them.

The import in the browser (security configuration) needs another format; for
that I need one file exported there ("Security configuration > Export").


ROLES PER LICENSE FROM THE USAGE
--------------------------------

    roles <- build_license_roles(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
                                 usage = usage,
                                 export_folder = file.path(export_folder, "Lizenzrollen"))
    roles$Summary

Without licenses: one role per base license the used objects need. With
licenses = "Supply Chain Management": only that role. users = c("id1", "id2"):
only the usage of these users counts. Without usage: every privilege is kept.

A privilege counts as used when one of its forms was opened; privileges
without a form (actions, entities, services) come in with their duty. A
privilege the license covers only partly becomes a new privilege
<privilege>_<SCM|FIN|COM>. Files: AxSecurityRole\, AxSecurityPrivilege\, one
zip, and a workbook (Überblick, Rollen, Neue Rechte, Rechte, Objekte,
Benutzer, Legende).


EARLIER FUNCTIONS, UNCHANGED
----------------------------

plan_single_license_role(), check_duty_against_role(), compare_role_versions()
and compare_role_version_pairs() with load_role_mapping() work as in the
earlier zips; their calls are in the playbook (step 9) and in the Rmd.
