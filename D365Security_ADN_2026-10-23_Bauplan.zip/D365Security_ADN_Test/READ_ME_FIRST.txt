D365Security - role license report, duty check and single-license plan in ADN
=============================================================================

Packed on 2026-10-23 from the branch feat/role-license-decision-tool:
commit d819533 plus check_duty_against_role() and plan_single_license_role()
(not yet committed).


WHAT IS IN THIS FOLDER
----------------------

Playbook_Role_License_Report_Acceptance_ADN.Rmd
    The acceptance test of the report, step by step.

R\
    The 27 code files. The package does not have to be installed.

D365_Exports\
    The object lists of the role _WIBU_VERKAUF_INNENDIENST_MITARBEITER,
    exported from D365 in ADN on 2026-10-10, one file per license.

The folder holds no user data and no password. db_credentials.xlsx: use the
file on the ADN machine.

Do not source the single file check_duty_against_role.R from an earlier
download any more: it is an older version and would replace the new one.


LOADING THE CODE
----------------

1. Unzip close to the drive root, for example under Documents\RProjects.
   The folder that contains R\ is your repo_path.
2. R packages, once: install.packages(c("DBI", "odbc", "dplyr", "tibble",
   "tidyr", "lubridate", "openxlsx", "readxl", "knitr", "rmarkdown"))
3. Open the playbook in RStudio and run the chunks one by one (no "Knit"):
   "parameters", then "appendix-files" (the last chunk; it loads the 27
   files), then "connection". Skip "code-version" and "setup".


BUILDING PLAN FOR A ROLE WITH ONE LICENSE ONLY
----------------------------------------------

    plan <- plan_single_license_role(
      con         = cnn,
      source_role = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
      license     = "Supply Chain Management",
      target_role = "5CDA51EB-9559-4B27-88C4-14601045B1F0",   # or NULL for a new role
      export_path = file.path(export_folder, "Bauplan_Verkauf_Innendienst_SCM.xlsx"),
      language    = "de"
    )

Sheets: Überblick, Bauplan, Bausteine, Bleibt draußen, Legende.
In the sheet Bauplan the rows are coloured:
    no colour    only Supply Chain Management
    orange       shared with Commerce
    green        shared with Finance
    purple       shared with Commerce and Finance
    light blue   Operations - Activity is enough
    grey         Team Members or no license is enough
The column "Kommt hinein über" names the privilege to add for an object the
target role lacks. The Legende explains everything in German and English.


CHECK SINGLE DUTIES OR PRIVILEGES AGAINST ANOTHER ROLE
------------------------------------------------------

    result <- check_duty_against_role(
      con         = cnn,
      source_role = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
      duty        = c("RetailDiscountOfferMaintain", "RetailDiscountOfferView"),
      privilege   = NULL,
      target_role = "5CDA51EB-9559-4B27-88C4-14601045B1F0",
      license     = "Supply Chain Management",
      export_path = file.path(export_folder, "Pruefung_RetailDiscountOffer.xlsx"),
      language    = "de"
    )

The license name as D365 writes it: "Supply Chain Management", not "SCM".
