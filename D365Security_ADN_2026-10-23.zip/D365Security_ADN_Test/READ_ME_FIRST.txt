D365Security - role license report and duty check in ADN
=========================================================

Packed on 2026-10-23 from the branch feat/role-license-decision-tool:
commit d819533 plus the function check_duty_against_role() with its legend.


WHAT IS IN THIS FOLDER
----------------------

Playbook_Role_License_Report_Acceptance_ADN.Rmd
    The acceptance test of the report, step by step.

R\
    The 24 code files: the role license report, the comparison with D365
    and check_duty_against_role(). The package does not have to be
    installed.

D365_Exports\
    The object lists of the role _WIBU_VERKAUF_INNENDIENST_MITARBEITER,
    exported from D365 in ADN on 2026-10-10. One file per license: Team
    Members, Operations - Activity, Commerce, Finance, Supply Chain
    Management. Keep only these five files in the folder.

The folder holds no user data and no password.


IMPORTANT IF YOU USED check_duty_against_role.R FROM THE DOWNLOADS FOLDER
-------------------------------------------------------------------------

The function is now part of the code files above. Do not source the single
file check_duty_against_role.R any more: it is an older version and would
replace the new one in your R session. Delete it on the ADN machine.


WHAT IS NOT IN THIS FOLDER
--------------------------

db_credentials.xlsx
    Use the file that is on the ADN machine. It needs the sheet
    AllConnections with a row for ADN and the columns Umgebung, server,
    database, uid, pwd.

Telemetry
    The playbook loads it with the package D365Licensing. See step 6 below.


BEFORE THE FIRST RUN
--------------------

1. Unzip close to the drive root, for example under Documents\RProjects:
   the export file names are long, and Windows refuses paths over 260
   characters. The folder that contains R\ is your repo_path.

2. Install the R packages, once. R must be version 4.1 or newer.

       install.packages(c("DBI", "odbc", "dplyr", "tibble", "tidyr",
                          "lubridate", "openxlsx", "readxl", "knitr",
                          "rmarkdown"))

3. Open the playbook in RStudio. Run the chunks one by one. Do not use
   "Knit": it would try to load the whole package.

4. Chunk "parameters": set repo_path, cred_path, export_folder,
   d365_export_folder (the folder D365_Exports here) and key_path (a file
   in a folder that is NOT inside export_folder). Then run the chunk.

5. Skip the chunks "code-version" and "setup". Run the chunk
   "appendix-files" instead (the last chunk); it loads the 24 files.

6. Chunk "step-2-telemetry": run it if the package D365Licensing is
   installed; otherwise run  usage <- NULL  instead.

7. Continue with the chunk "connection" and follow the playbook.


CHECK DUTIES OR PRIVILEGES AGAINST ANOTHER ROLE
-----------------------------------------------

After the chunks "parameters", "appendix-files" and "connection":

    result <- check_duty_against_role(
      con         = cnn,
      source_role = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
      duty        = c("RetailDiscountOfferMaintain", "RetailDiscountOfferView"),
      privilege   = NULL,
      target_role = "5CDA51EB-9559-4B27-88C4-14601045B1F0",
      license     = "Supply Chain Management",
      export_path = file.path(export_folder, "Check_RetailDiscountOffer.xlsx"),
      language    = "de"
    )

- duty, privilege or both: give the AOT names; several at once are fine.
- license: as D365 names it, e.g. "Supply Chain Management", not "SCM".
- language: "de" or "en" for sheet names, headers and values.

The workbook has five sheets: Overview, Gaps, Privileges, Not closable and
Legend (German: Überblick, Lücken, Rechte, Nicht schließbar, Legende). The
legend explains every column and value in English and German.

In the sheet Privileges, the column Action (Maßnahme) says what to do:
    add: closes n gaps        add this privilege to the target role
    already in the role       nothing to do
    not possible: ...         do not add: it needs another license
    not needed: ...           nothing to do; it closes no gap


THE REPORTS OF STEP 7
---------------------

export_folder\              for you: real user ids
    ..._MITARBEITER.xlsx, ..._MITARBEITER_de.xlsx, ..._without_users.xlsx

export_folder\to_share\     for the stakeholders: pseudonyms
    ..._MITARBEITER_pseudonymized.xlsx, ..._pseudonymized_de.xlsx

Show or pass on only files from to_share. Step 7 counts the cells in them
that hold a real user id; the count must be 0.
