D365Security - acceptance test of the role license report in ADN
================================================================

Packed on 2026-10-12 from the branch feat/role-license-decision-tool,
commit 5a4f531.


WHAT IS IN THIS FOLDER
----------------------

Playbook_Role_License_Report_Acceptance_ADN.Rmd
    The test, step by step.

R\
    The 21 code files the test needs. The package does not have to be
    installed.

D365_Exports\
    The object lists of the role _WIBU_VERKAUF_INNENDIENST_MITARBEITER,
    exported from D365 in ADN on 2026-10-10. One file per license: Team
    Members, Operations - Activity, Commerce, Finance, Supply Chain
    Management. Keep only these five files in the folder.

The folder holds no user data and no password.


WHAT IS NOT IN THIS FOLDER
--------------------------

db_credentials.xlsx
    It holds the database password and is left out on purpose. Use the file
    that is on the ADN machine. It needs the sheet AllConnections with a row
    for ADN and the columns Umgebung, server, database, uid, pwd.

Telemetry
    The playbook loads it with the package D365Licensing. See step 6 below.


BEFORE THE FIRST RUN
--------------------

1. Unzip. The folder that contains R\ is your repo_path.

2. Install the R packages, once. R must be version 4.1 or newer.

       install.packages(c("DBI", "odbc", "dplyr", "tibble", "tidyr",
                          "lubridate", "openxlsx", "readxl", "knitr",
                          "rmarkdown"))

3. Open the playbook in RStudio. Run the chunks one by one. Do not use
   "Knit": it would try to load the whole package.

4. Chunk "parameters": set these values, then run the chunk.

       repo_path           this folder (the one that contains R\)
       cred_path           db_credentials.xlsx on the ADN machine
       export_folder       a new, empty folder for the workbooks
       d365_export_folder  the folder D365_Exports in this folder
       key_path            a file in a folder that is NOT inside export_folder

   Leave environment, role and translation_path as they are.

5. Skip the chunks "code-version" and "setup". Run the chunk
   "appendix-files" instead. It is the last chunk of the playbook and loads
   the 21 files.

6. Chunk "step-2-telemetry":
   - If the package D365Licensing is installed on this machine, run the
     chunk as it is.
   - If not, run this line instead:

         usage <- NULL

     Steps 1, 3, 4, 5 and 7 then run as written, and the test can pass.
     Step 6 shows "no data" for the users; that part stays open.

7. Continue with the chunk "connection" and follow the playbook.


WHEN THE TEST HAS PASSED
------------------------

- Step 1 runs without an error.
- Every row of the table in step 4 says ok.
- Step 5 says Passed: TRUE.
- The workbooks of step 7 open and read correctly.

If something goes wrong, the table "If something goes wrong" near the end of
the playbook says what it means and what to do.
