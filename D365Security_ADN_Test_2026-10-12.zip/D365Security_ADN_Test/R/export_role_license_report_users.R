# =============================================================================
# User sheets of the role license report
#
# Used by export_role_license_report(). The sheets show who actually uses the
# building blocks of the role that need a base license.
# =============================================================================

.USER_OVERVIEW_WIDTHS <- c(44, 34, 46, 44, 24, 24, 24, 24, 24, 24)

.add_user_sheets <- function(workbook, report, texts, styles) {

  sheets <- texts$sheets_users

  .add_text_sheet(workbook, sheets[[1]], .user_overview_parts(report, texts), styles, .USER_OVERVIEW_WIDTHS)
  .add_table_sheet(workbook, sheets[[2]], .users_sheet(report, texts), styles)
  .add_table_sheet(workbook, sheets[[3]], .user_blocks_sheet(report, texts), styles)
  .add_table_sheet(workbook, sheets[[4]], .duty_usage_sheet(report, texts), styles)
  .add_table_sheet(workbook, sheets[[5]], .user_duties_sheet(report, texts), styles)
  .add_table_sheet(workbook, sheets[[6]], .other_roles_sheet(report, texts), styles)

  invisible(workbook)
}

# =============================================================================
# User overview
# =============================================================================

.user_overview_parts <- function(report, texts) {

  sections <- texts$sections_users

  c(
    list(
      .part("title", texts$users_title),
      .part("text", texts$users_subtitle),
      .part("gap"),
      .part("section", sections[["basis"]]),
      .part("bullets", .usage_basis_lines(report, texts)),
      .part("gap"),
      .part("section", sections[["meaning"]]),
      .part("bullets", .usage_meaning_lines(report, texts)),
      .part("gap")
    ),
    .table_section(sections[["licenses"]], .license_usage_table(report, texts)),
    .table_section(sections[["blocks"]], .block_usage_table(report, texts)),
    list(
      .part("section", sections[["reading"]]),
      .part("bullets", sprintf(texts$user_reading, texts$sheets_users[2:6])),
      .part("gap"),
      .part("section", sections[["limits"]]),
      .part("bullets", texts$user_limits)
    )
  )
}

.usage_basis_lines <- function(report, texts) {

  users    <- report$Users
  known    <- sum(users$HAS_USAGE_DATA)
  seen     <- users$LAST_SEEN[!is.na(users$LAST_SEEN)]
  disabled <- report$Role$DISABLED_USERS

  c(
    sprintf(texts$basis_users, nrow(users), known, nrow(users) - known),
    if (!is.null(disabled) && disabled > 0L) sprintf(texts$basis_disabled, disabled),
    if (length(seen) > 0L) {
      sprintf(
        texts$basis_window,
        format(min(seen), texts$date_format), format(max(seen), texts$date_format)
      )
    },
    texts$basis_notes
  )
}

.usage_meaning_lines <- function(report, texts) {

  if (!any(report$Users$HAS_USAGE_DATA)) {
    return(c(texts$meaning_no_usage, .other_roles_line(report, texts)))
  }

  rating         <- report$DutyUsage$RATING
  no_form_opened <- sum(rating %in% c(.USAGE_NOT_USED, .USAGE_PARTLY_MEASURABLE))

  c(
    .license_usage_lines(report, texts),
    .other_roles_line(report, texts),
    sprintf(
      texts$meaning_duties,
      no_form_opened, length(rating),
      sum(rating == .USAGE_PARTLY_MEASURABLE), sum(rating == .USAGE_NOT_MEASURABLE),
      texts$sheets_users[[4]]
    )
  )
}

# Number of rows per key that carry the given value, in the order of `keys`.
.count_rows <- function(row_keys, row_values, keys, value) {
  vapply(
    keys,
    function(key) sum(row_keys == key & row_values == value),
    integer(1),
    USE.NAMES = FALSE
  )
}

# Number of users per fixing license with the given status.
.users_per_license <- function(report, status) {
  .count_rows(
    report$UserLicenses$SKUNAME, report$UserLicenses$STATUS,
    report$Licenses$SKUNAME, status
  )
}

.license_usage_lines <- function(report, texts) {

  licenses <- report$Licenses

  if (nrow(licenses) == 0L) {
    return(texts$meaning_no_fixing)
  }

  users_with <- function(status) .users_per_license(report, status)

  ifelse(
    licenses$JUDGEABLE,
    sprintf(
      texts$meaning_judgeable, licenses$SKUNAME,
      users_with(.USAGE_USED), users_with(.USAGE_NOT_OBSERVED),
      licenses$MEASURABLE_COUNT, licenses$FIXING_OBJECT_COUNT
    ),
    sprintf(
      texts$meaning_unclear, licenses$SKUNAME, users_with(.USAGE_USED),
      licenses$MEASURABLE_COUNT, licenses$FIXING_OBJECT_COUNT
    )
  )
}

.other_roles_line <- function(report, texts) {

  users             <- report$Users
  with_license_data <- sum(users$LICENSES_TODAY != "")

  if (with_license_data == 0L) {
    return(texts$meaning_no_license_data)
  }

  sprintf(
    texts$meaning_other_roles,
    sum(users$VIA_OTHER_ROLES != ""), with_license_data, texts$sheets_users[[6]]
  )
}

.license_usage_table <- function(report, texts) {

  licenses <- report$Licenses

  .sheet_table(
    texts$columns_license_usage,
    licenses$SKUNAME,
    licenses$FIXING_OBJECT_COUNT,
    licenses$MEASURABLE_COUNT,
    .users_per_license(report, .USAGE_USED),
    .users_per_license(report, .USAGE_NOT_OBSERVED),
    .users_per_license(report, .USAGE_UNCLEAR),
    .users_per_license(report, .USAGE_NO_DATA)
  )
}

.block_usage_table <- function(report, texts) {

  blocks <- .sort_by_need(report$Blocks, report$Blocks$BLOCK_TYPE, report$Blocks$BLOCK_NAME)
  blocks <- blocks[blocks$IS_BASE, ]
  rated  <- report$UserBlocks

  # a duty and a privilege can share a technical name
  rated_key <- paste(rated$BLOCK_TYPE, rated$BLOCK_ID)
  block_key <- paste(blocks$BLOCK_TYPE, blocks$BLOCK_ID)
  any_row   <- match(block_key, rated_key)

  users_with <- function(rating) .count_rows(rated_key, rated$RATING, block_key, rating)

  .sheet_table(
    texts$columns_block_summary,
    .need_label(blocks$NEED, blocks$IS_BASE, texts),
    unname(texts$block_types[blocks$BLOCK_TYPE]),
    blocks$BLOCK_NAME,
    blocks$BLOCK_ID,
    sprintf(texts$count_of, rated$BASE_MEASURABLE_COUNT[any_row], rated$BASE_OBJECT_COUNT[any_row]),
    users_with(.USAGE_USED),
    users_with(.USAGE_PARTIAL),
    users_with(.USAGE_NOT_USED),
    users_with(.USAGE_NOT_MEASURABLE),
    users_with(.USAGE_NO_DATA)
  )
}

# =============================================================================
# User tables
# =============================================================================

# One sentence per group of licenses: not observed, unclear, in use.
.user_hints <- function(users, texts) {

  sentence <- function(template, licenses) {
    ifelse(licenses == "", "", sprintf(template, .display_list(licenses)))
  }

  hint <- trimws(paste(
    sentence(texts$hints[["NOT_OBSERVED"]], users$LICENSES_NOT_OBSERVED),
    sentence(texts$hints[["UNCLEAR"]], users$LICENSES_UNCLEAR),
    sentence(texts$hints[["USED"]], users$LICENSES_USED)
  ))
  hint <- gsub(" {2,}", " ", hint)
  hint <- ifelse(hint == "", texts$hints[["NONE"]], hint)

  as.character(ifelse(users$HAS_USAGE_DATA, hint, texts$hints[["NO_DATA"]]))
}

.users_sheet <- function(report, texts) {

  users <- report$Users
  # candidates first, users without usage data last
  users <- users[order(!users$HAS_USAGE_DATA, users$LICENSES_NOT_OBSERVED == "", users$USERID), ]

  has_license_data <- users$LICENSES_TODAY != ""
  other_roles      <- ifelse(users$VIA_OTHER_ROLES == "", texts$none, .display_list(users$VIA_OTHER_ROLES))

  list(
    data = .sheet_table(
      texts$columns_users,
      users$USERID,
      texts$yes_no[ifelse(users$HAS_USAGE_DATA, 1L, 2L)],
      .user_hints(users, texts),
      .display_list(users$LICENSES_USED),
      .display_list(users$LICENSES_NOT_OBSERVED),
      .display_list(users$LICENSES_UNCLEAR),
      sprintf(texts$count_of, users$DUTIES_USED, users$DUTY_COUNT),
      users$LAST_SEEN,
      ifelse(has_license_data, .display_list(users$LICENSES_TODAY), texts$no_license_data),
      ifelse(has_license_data, other_roles, texts$no_license_data),
      "", ""
    ),
    highlight = rep(FALSE, nrow(users)),
    widths    = c(18, 14, 90, 34, 34, 34, 14, 13, 44, 34, 22, 40)
  )
}

.user_blocks_sheet <- function(report, texts) {

  blocks <- report$UserBlocks

  list(
    data = .sheet_table(
      texts$columns_user_blocks,
      blocks$USERID,
      unname(texts$block_types[blocks$BLOCK_TYPE]),
      blocks$BLOCK_NAME,
      blocks$BLOCK_ID,
      .need_label(blocks$NEED, rep(TRUE, nrow(blocks)), texts),
      blocks$TOUCHES,
      blocks$BASE_TOUCHES,
      sprintf(texts$count_of, blocks$BASE_MEASURABLE_COUNT, blocks$BASE_OBJECT_COUNT),
      blocks$LAST_SEEN,
      unname(texts$rating_block[blocks$RATING])
    ),
    highlight = rep(FALSE, nrow(blocks)),
    widths    = c(18, 12, 52, 42, 44, 10, 16, 18, 13, 40)
  )
}

# Adds the license need of each duty to a usage table.
.with_duty_need <- function(usage, duties) {
  usage |>
    dplyr::left_join(
      dplyr::select(duties, DUTYIDENTIFIER, NEED, IS_BASE, NEED_PRIORITY),
      by = "DUTYIDENTIFIER"
    ) |>
    dplyr::mutate(
      NEED    = dplyr::coalesce(NEED, .NEED_UNKNOWN),
      IS_BASE = dplyr::coalesce(IS_BASE, FALSE)
    )
}

.duty_usage_sheet <- function(report, texts) {

  usage <- .with_duty_need(report$DutyUsage, report$Duties)
  usage <- .sort_by_need(usage, usage$USERS_WITH_USE, usage$DUTYNAME)

  list(
    data = .sheet_table(
      texts$columns_duty_usage,
      usage$DUTYNAME,
      usage$DUTYIDENTIFIER,
      .need_label(usage$NEED, usage$IS_BASE, texts),
      .level_label(usage$NEED, usage$IS_BASE, texts),
      usage$USERS_WITH_USE,
      usage$TOUCHES,
      usage$LAST_SEEN,
      unname(texts$rating_duty[usage$RATING]),
      sprintf(texts$count_of, usage$MEASURABLE_COUNT, usage$ENTRYPOINT_COUNT),
      "", ""
    ),
    highlight = usage$IS_BASE,
    widths    = c(62, 44, 44, 22, 12, 10, 13, 24, 16, 20, 40)
  )
}

.user_duties_sheet <- function(report, texts) {

  usage <- report$UserDutyUsage
  usage <- .with_duty_need(usage[usage$DUTYIDENTIFIER != .DIRECT_DUTY_ID, ], report$Duties)
  usage <- usage[order(usage$USERID, -usage$TOUCHES, usage$DUTYNAME), ]

  list(
    data = .sheet_table(
      texts$columns_user_duties,
      usage$USERID,
      usage$DUTYNAME,
      usage$DUTYIDENTIFIER,
      .need_label(usage$NEED, usage$IS_BASE, texts),
      usage$TOUCHES,
      usage$LAST_SEEN,
      unname(texts$evidence[usage$EVIDENCE])
    ),
    highlight = usage$IS_BASE,
    widths    = c(18, 62, 44, 44, 10, 13, 34)
  )
}

.other_roles_sheet <- function(report, texts) {

  roles <- report$OtherRoles
  roles <- roles[order(roles$USERID, roles$SKUNAME, roles$ROLEIDENTIFIER), ]

  list(
    data = .sheet_table(
      texts$columns_other_roles,
      roles$USERID,
      roles$SKUNAME,
      dplyr::coalesce(roles$SECURITYROLENAME, roles$ROLEIDENTIFIER),
      roles$ROLEIDENTIFIER
    ),
    highlight = rep(FALSE, nrow(roles)),
    widths    = c(18, 34, 56, 48)
  )
}
