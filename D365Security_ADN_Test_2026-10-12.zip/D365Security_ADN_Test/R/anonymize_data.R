#' Benutzer-, Personen- und Produktdaten pseudonymisieren
#'
#' Ersetzt in einer Tabelle oder einer Liste von Tabellen die Werte
#' personen- und produktbezogener Spalten durch Pseudonyme wie
#' \code{USER_K7QF_0001} und führt eine Schlüsseldatei, mit der sich die
#' echten Werte wiederherstellen lassen (\code{\link{deanonymize_data}},
#' \code{\link{deanonymize_workbook}}).
#'
#' @details
#'
#' **Welche Spalten**
#'
#' Die Spalten werden am Namen erkannt, ohne Beachtung der
#' Groß-/Kleinschreibung. \code{columns} ordnet jeder Kategorie Regex-Muster
#' zu; der Name der Kategorie wird zum Präfix des Pseudonyms. Spalten, deren
#' Name auf ein Muster aus \code{keep} passt, bleiben immer unverändert:
#' Rollen, Duties, Privileges, Lizenzen und Entry Points sind Konfiguration
#' und keine personenbezogenen Daten.
#'
#' Erkannt wird nur am Spaltennamen. Steht ein echter Wert zusätzlich in
#' einer Spalte, die nicht pseudonymisiert wurde (zum Beispiel
#' \code{ROLE_OWNER}), warnt die Funktion und nennt Tabelle und Spalte. Dann
#' \code{columns} oder \code{keep} anpassen. Freitext wird nicht durchsucht.
#'
#' Zahlen in erkannten Spalten werden zu Text. Listenspalten lassen sich
#' nicht pseudonymisieren; die Funktion bricht in diesem Fall ab, statt
#' echte Werte stehen zu lassen.
#'
#' **Schlüsseldatei**
#'
#' Die Schlüsseldatei ist eine Excel-Arbeitsmappe mit dem Blatt \code{Key}
#' und den Spalten \code{CATEGORY}, \code{ORIGINAL}, \code{PSEUDONYM}. Sie
#' enthält die echten Werte und gehört nicht weitergegeben: Sie bleibt in
#' der Umgebung, aus der die Daten stammen, und liegt nicht im selben Ordner
#' wie die Dateien, die weitergegeben werden.
#'
#' \itemize{
#'   \item Existiert die Datei schon, wird sie weiterverwendet und nur um
#'     neue Werte ergänzt. Derselbe Wert erhält dadurch in jedem Lauf
#'     dasselbe Pseudonym.
#'   \item Jede Schlüsseldatei hat eine eigene Kennung, die in jedem
#'     Pseudonym steht (\code{K7QF} in \code{USER_K7QF_0001}). Pseudonyme
#'     lassen sich deshalb nur mit der Datei zurückführen, die sie erzeugt
#'     hat.
#'   \item Die Funktion verwaltet die Datei allein. Zeilen nicht löschen
#'     oder ändern: Eine beschädigte Datei wird abgelehnt. Zusätzliche
#'     Blätter gehen beim nächsten Schreiben verloren.
#'   \item Eine vorhandene Datei, die keine Schlüsseldatei ist, wird nicht
#'     überschrieben.
#'   \item Nicht aus mehreren R-Sitzungen gleichzeitig in dieselbe Datei
#'     schreiben.
#' }
#'
#' **Was die Pseudonyme verraten**
#'
#' \itemize{
#'   \item Die Nummern werden zufällig vergeben, unabhängig von einem
#'     gesetzten Seed, und die Zeilen werden nach dem Pseudonym sortiert.
#'     Weder Nummer noch Reihenfolge lassen auf den echten Wert schließen.
#'   \item Derselbe Wert in anderer Groß-/Kleinschreibung oder mit
#'     Leerzeichen am Rand erhält dasselbe Pseudonym. Zurückgeführt wird die
#'     zuerst gesehene Schreibweise.
#'   \item Fehlende und leere Werte bleiben unverändert. Ein Wert, der schon
#'     ein Pseudonym der Schlüsseldatei ist, wird nicht erneut ersetzt.
#' }
#'
#' Es handelt sich um eine Pseudonymisierung, keine Anonymisierung: Alle
#' übrigen Spalten (zum Beispiel Nutzungszahlen, Zeitpunkte und
#' Lizenzkombinationen) bleiben erhalten. Wer die Benutzer kennt, kann
#' daraus bei kleinen Gruppen auf einzelne Personen schließen.
#'
#' @param data
#' Data Frame oder Liste von Data Frames. Listenelemente, die keine Data
#' Frames sind, bleiben unverändert.
#'
#' @param key_path
#' Pfad der Schlüsseldatei (\code{.xlsx}). Wird angelegt oder ergänzt.
#'
#' @param columns
#' Benannte Liste: je Kategorie die Regex-Muster der Spaltennamen. Die Namen
#' bestehen aus Großbuchstaben und Ziffern. Standard:
#' \code{\link{default_anonymization_columns}}.
#'
#' @param keep
#' Regex-Muster für Spaltennamen, die nie pseudonymisiert werden.
#'
#' @return
#' \code{data} in derselben Form, mit Pseudonymen in den erkannten Spalten.
#' Tabellen mit pseudonymisierten Spalten sind nach dem Pseudonym sortiert.
#'
#' @examples
#' \dontrun{
#'
#' users <- tibble::tibble(
#'   USERID         = c("wibule01", "wibule02"),
#'   ROLEIDENTIFIER = c("_WIBU_VERKAUF_KEYACCOUNT", "_WIBU_EINKAUF_MITARBEITER")
#' )
#'
#' # Die Schlüsseldatei liegt außerhalb des Ordners, der weitergegeben wird.
#' key_path <- "C:/D365_Schluessel/anonymization_key.xlsx"
#'
#' anonymized <- anonymize_data(users, key_path)
#'
#' # Nur Kundennummern, mit eigenem Präfix CUSTOMER_
#' anonymize_data(
#'   customers,
#'   key_path = key_path,
#'   columns  = list(CUSTOMER = "^CUSTACCOUNT$")
#' )
#'
#' }
#'
#' @seealso
#' \code{\link{deanonymize_data}}
#' \code{\link{deanonymize_workbook}}
#' \code{\link{analyze_role_license_decision}}
#'
#' @export
anonymize_data <- function(
  data,
  key_path,
  columns = default_anonymization_columns(),
  keep    = c("ROLE", "DUTY", "PRIVILEGE", "SKU", "LICENSE", "ENTRYPOINT")
) {

  .check_key_path(key_path)
  .check_anonymization_columns(columns)
  .check_keep_patterns(keep)

  tables <- .as_table_list(data)
  plans  <- lapply(tables, .column_categories, columns = columns, keep = keep)
  .check_planned_columns(tables, plans)

  existing <- .read_anonymization_key(key_path)
  key      <- .extend_anonymization_key(existing, .collect_planned_values(tables, plans))

  # Ohne neue Werte bleibt eine vorhandene Schluesseldatei unberuehrt.
  if (!file.exists(key_path) || nrow(key) > nrow(existing)) {
    .write_anonymization_key(key, key_path)
  }

  anonymized <- Map(.apply_pseudonyms, tables, plans, MoreArgs = list(key = key))
  .warn_remaining_originals(anonymized, plans, key)

  .restore_table_shape(anonymized, data)
}

#' Standardspalten für die Pseudonymisierung
#'
#' Liefert je Kategorie die Regex-Muster der Spaltennamen, die
#' \code{\link{anonymize_data}} ohne weitere Angabe pseudonymisiert.
#'
#' @return
#'
#' Benannte Liste mit den Kategorien \code{USER} (Benutzerkennungen),
#' \code{EMAIL} (E-Mail-Adressen), \code{PERSON} (Namen und Kennungen von
#' Personen) und \code{PRODUCT} (Artikel und Produkte).
#'
#' @examples
#' default_anonymization_columns()
#'
#' # Standard um Kundennummern erweitern
#' c(default_anonymization_columns(), list(CUSTOMER = "^CUSTACCOUNT$"))
#'
#' @seealso
#' \code{\link{anonymize_data}}
#'
#' @export
default_anonymization_columns <- function() {
  list(
    USER = c(
      "^USER$", "^USER_?ID$", "^USER_?NAME$", "^USER_?KEY$",
      "^USER_?PRINCIPAL_?NAME$", "^UPN$", "^NETWORK_?ALIAS$", "^ALIAS$",
      "^LOGIN(_?NAME)?$", "^CREATED_?BY$", "^MODIFIED_?BY$"
    ),
    EMAIL = "E_?MAIL",
    PERSON = c(
      "^PERSON", "^WORKER", "^EMPLOYEE", "^FIRST_?NAME$", "^LAST_?NAME$",
      "^MIDDLE_?NAME$", "^FULL_?NAME$", "^DISPLAY_?NAME$", "^PARTY_?NUMBER$",
      "^PHONE", "^TELEPHONE", "^BIRTH"
    ),
    PRODUCT = c(
      "^ITEM$", "^ITEM_?(ID|NUMBER|NAME|DESCRIPTION)$", "^PRODUCT$",
      "^PRODUCT_?(ID|NUMBER|NAME|DESCRIPTION|SEARCH_?NAME|VARIANT_?NUMBER)$",
      "^SEARCH_?NAME$"
    )
  )
}

# =============================================================================
# Interne Hilfsfunktionen: Spalten erkennen und Werte ersetzen.
# Die Schluesseldatei selbst steht in anonymization_key.R.
# =============================================================================

.check_anonymization_columns <- function(columns) {

  categories <- names(columns)

  is_valid <- is.list(columns) &&
    length(columns) > 0L &&
    !is.null(categories) &&
    all(grepl("^[A-Z][A-Z0-9]*$", categories)) &&
    anyDuplicated(categories) == 0L &&
    all(vapply(columns, is.character, logical(1)))

  if (!is_valid) {
    stop(
      "columns muss eine benannte Liste von Regex-Mustern sein. Die Namen ",
      "(z.B. USER) sind eindeutig und bestehen aus Großbuchstaben und Ziffern."
    )
  }

  invisible(columns)
}

.check_keep_patterns <- function(keep) {

  if (!is.character(keep) || anyNA(keep)) {
    stop("keep muss ein Character-Vektor mit Regex-Mustern sein.")
  }

  invisible(keep)
}

# Eine einzelne Tabelle wird wie eine Liste mit einer Tabelle behandelt.
.as_table_list <- function(data) {

  if (is.data.frame(data)) {
    return(list(data))
  }

  if (!is.list(data)) {
    stop("data muss ein Data Frame oder eine Liste von Data Frames sein.")
  }

  data
}

.restore_table_shape <- function(tables, data) {
  if (is.data.frame(data)) tables[[1]] else tables
}

# Bezeichnung der Tabellen fuer Meldungen.
.table_labels <- function(tables) {

  labels <- names(tables)

  if (is.null(labels)) {
    labels <- rep("", length(tables))
  }

  ifelse(nzchar(labels), labels, paste0("Tabelle ", seq_along(tables)))
}

.is_text_column <- function(column) {
  is.character(column) || is.factor(column)
}

.matches_any <- function(x, patterns) {
  Reduce(
    `|`,
    lapply(patterns, grepl, x = x, ignore.case = TRUE),
    rep(FALSE, length(x))
  )
}

# Kategorie je Spalte, NA fuer Spalten, die unveraendert bleiben. Die Zuordnung
# laeuft ueber die Position, damit doppelte Spaltennamen nichts verfaelschen.
.column_categories <- function(table, columns, keep) {

  if (!is.data.frame(table)) {
    return(character())
  }

  column_names <- names(table)

  category <- vapply(column_names, function(column_name) {
    hits <- names(columns)[vapply(columns, .matches_any, logical(1), x = column_name)]
    if (length(hits) == 0L) NA_character_ else hits[[1]]
  }, character(1), USE.NAMES = FALSE)

  category[.matches_any(column_names, keep)] <- NA_character_
  category
}

# Listenspalten lassen sich nicht ersetzen. Abbruch statt echte Werte stehen
# zu lassen.
.check_planned_columns <- function(tables, plans) {

  list_columns <- unlist(Map(function(table, plan, label) {
    planned <- which(!is.na(plan))
    is_list <- vapply(planned, function(index) is.list(table[[index]]), logical(1))
    paste0(label, "$", names(table)[planned[is_list]], recycle0 = TRUE)
  }, tables, plans, .table_labels(tables)))

  if (length(list_columns) > 0L) {
    stop(
      "Listenspalten lassen sich nicht pseudonymisieren: ",
      paste(list_columns, collapse = ", "),
      ". Die Spalte vorher auflösen oder entfernen."
    )
  }

  invisible(NULL)
}

# Text fuer den Schluessel. Zahlen ohne Exponentialschreibweise: 100000 statt 1e+05.
.as_text <- function(values) {

  if (!is.numeric(values)) {
    return(as.character(values))
  }

  text    <- rep(NA_character_, length(values))
  present <- !is.na(values)

  text[present] <- vapply(
    values[present], format, character(1),
    scientific = FALSE, digits = 15L
  )

  text
}

# Alle Werte der zu pseudonymisierenden Spalten, mit ihrer Kategorie.
.collect_planned_values <- function(tables, plans) {

  collected <- Map(function(table, plan) {
    lapply(which(!is.na(plan)), function(index) {
      values <- .as_text(table[[index]])
      tibble::tibble(
        CATEGORY = plan[[index]],
        ORIGINAL = values[!is.na(values) & nzchar(trimws(values))]
      )
    })
  }, tables, plans)

  # Ohne Namen binden: Eine benannte Liste hielte bind_rows() fuer eine
  # einzelne Tabelle mit den Listennamen als Spalten.
  dplyr::bind_rows(c(
    list(.empty_anonymization_key()[, c("CATEGORY", "ORIGINAL")]),
    unname(unlist(collected, recursive = FALSE))
  ))
}

# Ersetzt die Werte der geplanten Spalten und sortiert nach dem Pseudonym,
# damit die Zeilenfolge nicht der Reihenfolge der echten Werte entspricht.
.apply_pseudonyms <- function(table, plan, key) {

  planned <- which(!is.na(plan))

  if (length(planned) == 0L) {
    return(table)
  }

  for (index in planned) {
    table[[index]] <- .pseudonymize_values(
      table[[index]],
      key[key$CATEGORY == plan[[index]], ]
    )
  }

  .sort_by_column(table, planned[[1]])
}

# Werte ohne Schluesseleintrag bleiben stehen: fehlende, leere und solche,
# die bereits Pseudonyme sind.
.pseudonymize_values <- function(values, known) {

  text     <- .as_text(values)
  position <- match(.identifier_key(text), .identifier_key(known$ORIGINAL))
  found    <- !is.na(position)

  text[found] <- known$PSEUDONYM[position[found]]
  text
}

.sort_by_column <- function(table, index) {

  sorted <- table[order(table[[index]], method = "radix"), , drop = FALSE]

  if (!inherits(table, "tbl_df")) {
    rownames(sorted) <- NULL
  }

  sorted
}

# Erkannt wird nur am Spaltennamen. Steht ein echter Wert zusaetzlich in einer
# unveraenderten Textspalte, waere er weiterhin lesbar: Tabelle und Spalte
# nennen, nicht den Wert.
.warn_remaining_originals <- function(tables, plans, key) {

  originals <- .identifier_key(key$ORIGINAL)

  leaks <- unlist(Map(function(table, plan, label) {
    if (!is.data.frame(table)) {
      return(character())
    }
    untouched <- which(is.na(plan) & vapply(table, .is_text_column, logical(1)))
    has_original <- vapply(untouched, function(index) {
      any(.identifier_key(table[[index]]) %in% originals)
    }, logical(1))
    paste0(label, "$", names(table)[untouched[has_original]], recycle0 = TRUE)
  }, tables, plans, .table_labels(tables)))

  if (length(leaks) > 0L) {
    warning(
      "Echte Werte stehen noch in Spalten, die nicht pseudonymisiert wurden: ",
      paste(leaks, collapse = ", "),
      ". Die Spalten in columns aufnehmen oder aus keep entfernen.",
      call. = FALSE
    )
  }

  invisible(leaks)
}
