#' Analyse the license need of a role from its name
#'
#' Loads everything the role license report needs from the database and
#' returns it as a list of tables: which license every building block of the
#' role needs, and which users actually use the blocks that need a base
#' license.
#'
#' @details
#'
#' **Steps**
#'
#' \enumerate{
#'   \item Load the role with its sub-roles, duties, privileges, objects and
#'     licenses, see "Data source".
#'   \item Work out the license per building block
#'     (\code{\link{build_role_license_report}}).
#'   \item Load the users of the role and their licenses over all roles
#'     (\code{\link{get_sql_user_role_assignments}},
#'     \code{\link{get_user_licenses_by_role}}).
#'   \item Compare the need with the usage
#'     (\code{\link{build_role_usage_report}}).
#' }
#'
#' Disabled users (\code{USERENABLED = 0}) are left out; the report states
#' their number.
#'
#' **Data source**
#'
#' The function reads the license graph of D365FO, the table
#' \code{LicensingSecurityObjectExplodedGraph}: one row per path role,
#' sub-role, duty, privilege and object, with the access level and the
#' license the object needs. It is what D365FO itself shows for the role.
#' Duties and privileges without an object that takes part in licensing are
#' not in that table; they are added from \code{UserSecGovRelatedObjects}.
#'
#' The table belongs to a preview feature (from version 10.0.47) and is
#' filled by a job. Where it is missing or holds no rows for the role, the
#' function says so and builds the report from \code{UserSecGovRelatedObjects}
#' and \code{LicensingPrivilegeRequirementsDetailedView}
#' (\code{\link{get_license_requirements}}) instead. \code{Role$SOURCE} is
#' \code{"graph"} or \code{"views"}, and the exported report names the source.
#'
#' Any other failure of the query on the table, such as a missing permission
#' or a timeout, stops the analysis: the second source must not take over
#' unnoticed.
#'
#' The function warns when rows of the table name no license, a license that
#' \code{LicensingAllSkus} does not list, or an object type the package does
#' not know. Such a license counts as covering nothing.
#'
#' **Usage data**
#'
#' \code{usage} is passed in by the caller, for example from
#' \code{D365Licensing::load_telemetry_touches()}. Without it the report
#' still shows the license need; the usage tables then say "no data".
#'
#' **Pseudonyms**
#'
#' With \code{anonymize = TRUE} the user ids in all tables are replaced by
#' pseudonyms. Roles, duties, privileges and licenses stay readable. See
#' \code{\link{anonymize_data}} and \code{\link{deanonymize_workbook}}.
#'
#' @param con
#' Database connection. Result of \code{get_connection()}.
#'
#' @param role_identifier
#' AOT name of exactly one role (\code{ROLEIDENTIFIER}).
#'
#' @param usage
#' Telemetry touches per user and entry point, see
#' \code{\link{analyze_user_duty_usage}}. \code{NULL} = no telemetry.
#'
#' @param base_group_pattern
#' Regex that recognises the group of base licenses. Default: \code{"^Base"}.
#'
#' @param measurable_type_pattern
#' Regex for the resource types the telemetry records. Default:
#' \code{"display|anzeige"}, see \code{\link{build_role_license_drivers}}.
#' With the license graph as source the types carry their AOT names, for
#' example \code{MenuItemDisplay}; the default matches these as well.
#'
#' @param anonymize
#' \code{TRUE} = replace user ids by pseudonyms. Default: \code{FALSE}.
#'
#' @param key_path
#' Path of the key file (\code{.xlsx}) for the pseudonyms; required with
#' \code{anonymize = TRUE}.
#'
#' @return
#'
#' List with the element \code{Role} (\code{IDENTIFIER}, \code{NAME},
#' \code{CREATED}, \code{DATABASE}, \code{HAS_USAGE}, \code{ANONYMIZED},
#' \code{DISABLED_USERS}, \code{SOURCE}) and
#' the tables of \code{\link{build_role_license_report}} and
#' \code{\link{build_role_usage_report}}.
#'
#' @examples
#' \dontrun{
#'
#' cnn   <- get_connection("ADN", "db_credentials.xlsx")
#' usage <- D365Licensing::load_telemetry_touches(D365Licensing::load_config())
#'
#' report <- analyze_role_license_report(
#'   con             = cnn,
#'   role_identifier = "_WIBU_VERKAUF_INNENDIENST_MITARBEITER",
#'   usage           = usage
#' )
#'
#' report$Blocks
#' report$Users
#'
#' export_role_license_report(report)
#'
#' }
#'
#' @seealso
#' \code{\link{report_role_license}}
#' \code{\link{export_role_license_report}}
#' \code{\link{build_role_license_report}}
#' \code{\link{build_role_usage_report}}
#'
#' @export
analyze_role_license_report <- function(
  con,
  role_identifier,
  usage                   = NULL,
  base_group_pattern      = "^Base",
  measurable_type_pattern = .MEASURABLE_TYPE_PATTERN,
  anonymize               = FALSE,
  key_path                = NULL
) {

  .check_single_role(role_identifier)
  .check_anonymize_request(anonymize, key_path)

  report_source <- .load_role_report_source(con, role_identifier, base_group_pattern)

  drivers <- build_role_license_drivers(
    report_source$role_objects, report_source$license_requirements,
    base_group_pattern      = base_group_pattern,
    measurable_type_pattern = measurable_type_pattern
  )
  role_part <- build_role_license_report(
    drivers, .role_structure(report_source$role_objects),
    .sku_table(report_source$license_requirements), base_group_pattern
  )

  users <- .load_active_role_users(con, role_identifier)

  usage_part <- build_role_usage_report(
    role_part, drivers,
    user_ids        = users$ids,
    usage           = usage,
    user_licenses   = users$licenses,
    role_identifier = role_identifier
  )

  role <- c(
    .describe_report_role(con, report_source$role_objects, role_identifier, usage, anonymize),
    list(DISABLED_USERS = users$disabled_count, SOURCE = report_source$source)
  )
  report <- c(list(Role = role), role_part, usage_part)

  if (!anonymize) {
    return(report)
  }

  anonymize_data(report, key_path)
}

# Role objects, license rows and the name of the source they come from.
#
# The license graph is the first choice: it is what D365FO itself shows for
# the role. A database without it is served from the security objects and the
# license views.
.load_role_report_source <- function(con, role_identifier, base_group_pattern) {

  available <- .load_available_license_graph(con, role_identifier)

  if (is.null(available)) {
    return(.load_role_source_from_views(con, role_identifier))
  }

  # Only the duties and privileges without a licensed object come from the
  # security objects here; the report stands without them.
  security_objects <- tryCatch(
    .load_role_report_objects(con, role_identifier),
    error = function(e) {
      warning(
        "Role '", role_identifier, "': the duties and privileges without a licensed object ",
        "are missing in the report, because the security objects could not be loaded: ",
        .without_sql_statement(conditionMessage(e)),
        call. = FALSE
      )
      NULL
    }
  )

  list(
    role_objects         = .add_unlicensed_privileges(.role_objects_from_graph(available$graph), security_objects),
    license_requirements = .license_rows_from_graph(available$graph, available$skus, base_group_pattern),
    source               = .SOURCE_GRAPH
  )
}

.load_role_source_from_views <- function(con, role_identifier) {

  role_objects <- .load_role_report_objects(con, role_identifier)

  if (nrow(role_objects) == 0L) {
    stop("No security objects found for role '", role_identifier, "'.")
  }

  list(
    role_objects         = role_objects,
    license_requirements = .load_report_license_requirements(con, role_objects, role_identifier),
    source               = .SOURCE_VIEWS
  )
}

# Security objects of a role including the sub-role each object comes from.
.load_role_report_objects <- function(con, role_identifier) {

  query <- paste0("
    SELECT DISTINCT
      USGRO.ROLEIDENTIFIER,
      USGRO.ROLENAME,
      USGRO.SUBROLEIDENTIFIER,
      USGRO.SUBROLENAME,
      USGRO.DUTYIDENTIFIER,
      USGRO.DUTYNAME,
      USGRO.PRIVILEGEIDENTIFIER,
      USGRO.PRIVILEGENAME,
      USGRO.RESOURCE_,
      USGRO.RESOURCETYPE
    FROM UserSecGovRelatedObjects USGRO
    WHERE USGRO.ROLEIDENTIFIER = ", DBI::dbQuoteString(con, role_identifier)
  )

  DBI::dbGetQuery(con, query) |>
    tibble::as_tibble()
}

.load_report_license_requirements <- function(con, role_objects, role_identifier) {

  privilege_ids <- unique(role_objects$PRIVILEGEIDENTIFIER)
  privilege_ids <- privilege_ids[!is.na(privilege_ids) & nzchar(privilege_ids)]

  # Without privileges get_license_requirements() would load the license
  # rows of every privilege in the system.
  if (length(privilege_ids) == 0L) {
    stop("Role '", role_identifier, "' contains no privileges.")
  }

  get_license_requirements(con, privilege_identifiers = privilege_ids, sku_name = NULL) |>
    tibble::as_tibble()
}

# Enabled users of the role (ids), their licenses over all roles (licenses)
# and the number of disabled users that were left out (disabled_count).
.load_active_role_users <- function(con, role_identifier) {

  assignments <- get_sql_user_role_assignments(con, roles = role_identifier)
  .check_required_columns(assignments, c("USERID", "SECURITYROLEIDENTIFIER"), "user role assignments")

  # `roles` also matches role names; only the identifier names this role
  is_this_role <- .identifier_key(assignments$SECURITYROLEIDENTIFIER) == .identifier_key(role_identifier)
  assigned_ids <- unique(assignments$USERID[is_this_role])

  user_licenses <- tryCatch(
    .load_user_licenses(con, assigned_ids),
    error = function(e) {
      stop(
        "Loading the licenses of the users of role '", role_identifier, "' failed: ",
        .without_sql_statement(conditionMessage(e)),
        call. = FALSE
      )
    }
  )
  disabled_keys <- .disabled_user_keys(user_licenses)
  is_disabled   <- tolower(assigned_ids) %in% disabled_keys

  list(
    ids            = assigned_ids[!is_disabled],
    licenses       = user_licenses[!tolower(user_licenses$USERID) %in% disabled_keys, ],
    disabled_count = sum(is_disabled)
  )
}

# Database errors repeat the failed statement, and the statement of a user
# query holds user ids. The message keeps the reason and drops the statement.
.without_sql_statement <- function(message) {
  sub("(?s)\\s*<SQL>.*$", " <SQL> [statement omitted]", .as_valid_text(message), perl = TRUE)
}

# A driver can deliver its message in the code page of the server instead of
# UTF-8, for example a German message with an umlaut. Such a text would stop
# every pattern match.
.as_valid_text <- function(text) {
  if (validUTF8(text)) text else iconv(text, "latin1", "UTF-8")
}

# One row per sub-role, duty and privilege. A row that names the role itself
# as its sub-role belongs to the role directly.
.role_structure <- function(role_objects) {

  .check_required_columns(role_objects, c("SUBROLEIDENTIFIER", "SUBROLENAME"), "role_objects")

  role_objects |>
    dplyr::mutate(
      IS_OWN_ROLE       = !is.na(SUBROLEIDENTIFIER) &
        .identifier_key(SUBROLEIDENTIFIER) == .identifier_key(ROLEIDENTIFIER),
      SUBROLEIDENTIFIER = dplyr::if_else(IS_OWN_ROLE, "", as.character(SUBROLEIDENTIFIER)),
      SUBROLENAME       = dplyr::if_else(IS_OWN_ROLE, "", as.character(SUBROLENAME))
    ) |>
    dplyr::distinct(SUBROLEIDENTIFIER, SUBROLENAME, DUTYIDENTIFIER, PRIVILEGEIDENTIFIER)
}

.describe_report_role <- function(con, role_objects, role_identifier, usage, anonymize) {

  role_names <- if ("ROLENAME" %in% names(role_objects)) role_objects$ROLENAME else character()
  role_names <- role_names[!is.na(role_names) & nzchar(role_names)]

  list(
    IDENTIFIER = role_identifier,
    NAME       = if (length(role_names) > 0L) role_names[[1]] else role_identifier,
    CREATED    = Sys.Date(),
    DATABASE   = .connection_database(con),
    HAS_USAGE  = !is.null(usage) && nrow(usage) > 0L,
    ANONYMIZED = anonymize
  )
}

# Name of the database, so that a report says which environment it describes.
# Not every driver reports it; the report is complete without it.
.connection_database <- function(con) {

  database <- tryCatch(DBI::dbGetInfo(con)$dbname, error = function(e) NULL)

  if (.is_single_string(database)) database else NA_character_
}
