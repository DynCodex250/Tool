#' Compare the license needs of a role with what its users actually use
#'
#' Shows, per user of a role, whether the objects that fix a license were
#' used, which base license blocks were used, which duties nobody uses, and
#' which other roles of a user trigger the same licenses.
#'
#' @details
#'
#' **Fixing licenses**
#'
#' An object fixes a license when only that license covers it. A role needs a
#' license for good only because of these objects; everything else is covered
#' by an alternative. The usage of exactly these objects is rated per user:
#'
#' \describe{
#'   \item{\code{USED}}{The user opened at least one fixing object.}
#'   \item{\code{NOT_OBSERVED}}{The user opened none, and enough of the fixing
#'     objects are measurable. A hint, not a proof.}
#'   \item{\code{UNCLEAR}}{The user opened none, but too few fixing objects are
#'     measurable to judge (fewer than \code{min_measurable_share}). Typical
#'     for licenses fixed by actions such as posting.}
#'   \item{\code{NO_DATA}}{There is no telemetry for the user at all.}
#' }
#'
#' Telemetry records opened forms only. Actions are not recorded.
#'
#' **Blocks**
#'
#' \code{UserBlocks} rates every building block that needs a base license:
#' \code{USED} (an object needing a base license was opened),
#' \code{NOT_MEASURABLE} (none of these objects is a form, so the usage cannot
#' judge the block), \code{PARTIAL} (only other objects of the block were
#' opened), \code{NOT_USED} or \code{NO_DATA}.
#'
#' **Duties**
#'
#' \code{DutyUsage} rates every duty over all users: \code{USED},
#' \code{NOT_USED} (no user opened a form of it), \code{PARTLY_MEASURABLE}
#' (no user opened a form, but a part of the duty with its own license holds
#' no form), \code{NOT_MEASURABLE} (the duty holds no form at all) or
#' \code{NO_DATA}.
#'
#' @param role_report
#' Result of \code{\link{build_role_license_report}}.
#'
#' @param drivers
#' Result of \code{\link{build_role_license_drivers}} for the same role.
#'
#' @param user_ids
#' Character vector with the ids of the users who have the role.
#'
#' @param usage
#' Telemetry touches per user and entry point, see
#' \code{\link{analyze_user_duty_usage}}. \code{NULL} = no telemetry.
#'
#' @param user_licenses
#' Result of \code{\link{get_user_licenses_by_role}} for these users across
#' all their roles, or \code{NULL}. Required columns: \code{USERID},
#' \code{ROLEIDENTIFIER}, \code{SKUNAME}.
#'
#' @param role_identifier
#' AOT name of the role.
#'
#' @param min_measurable_share
#' Share of fixing objects that must be measurable before "not opened" counts
#' as \code{NOT_OBSERVED}. Default: \code{0.5}.
#'
#' @return
#'
#' List of tibbles: \code{Licenses} (fixing licenses and how measurable they
#' are), \code{Users} (one row per user), \code{UserLicenses} (status per
#' user and fixing license), \code{UserBlocks}, \code{DutyUsage} (users per
#' duty), \code{UserDutyUsage} (result of
#' \code{\link{analyze_user_duty_usage}}) and \code{OtherRoles} (other roles
#' of a user that trigger a base license of this role).
#'
#' @examples
#' \dontrun{
#'
#' report <- analyze_role_license_report(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER", usage = usage)
#'
#' report$Users
#' report$OtherRoles
#'
#' }
#'
#' @seealso
#' \code{\link{build_role_license_report}}
#' \code{\link{analyze_role_license_report}}
#'
#' @export
build_role_usage_report <- function(
  role_report,
  drivers,
  user_ids,
  usage                = NULL,
  user_licenses        = NULL,
  role_identifier,
  min_measurable_share = 0.5
) {

  .check_role_report(role_report, c("Blocks", "ObjectNeeds", "BlockObjects"))
  .check_required_columns(drivers, .driver_columns(), "drivers")
  .check_single_role(role_identifier)

  if (!is.character(user_ids)) {
    stop("user_ids must be a character vector.")
  }

  is_share <- is.numeric(min_measurable_share) && length(min_measurable_share) == 1L &&
    !is.na(min_measurable_share) && min_measurable_share >= 0 && min_measurable_share <= 1

  if (!is_share) {
    stop("min_measurable_share must be one number between 0 and 1.")
  }

  touches <- .role_object_touches(drivers, usage, user_ids)
  users   <- .distinct_users(user_ids) |>
    dplyr::mutate(HAS_USAGE_DATA = USER_KEY %in% touches$known_users)

  licenses       <- .fixing_licenses(role_report$ObjectNeeds, min_measurable_share)
  rated_licenses <- .rate_user_licenses(users, licenses, role_report$ObjectNeeds, touches$per_object)
  duty_usage     <- analyze_user_duty_usage(drivers, user_ids, touches$checked)
  other_roles    <- .other_role_licenses(users, user_licenses, role_report, role_identifier)

  list(
    Licenses      = dplyr::select(licenses, -NEED_PRIORITY),
    Users         = .summarize_users(users, rated_licenses, duty_usage, touches$per_object, user_licenses, other_roles),
    UserLicenses  = dplyr::select(rated_licenses, USERID, SKUNAME, STATUS, TOUCHES),
    UserBlocks    = .rate_user_blocks(users, role_report, touches$per_object),
    DutyUsage     = .summarize_duty_usage(duty_usage, any(users$HAS_USAGE_DATA)),
    UserDutyUsage = duty_usage,
    OtherRoles    = dplyr::select(other_roles, -USER_KEY)
  )
}

.USAGE_USED              <- "USED"
.USAGE_NOT_OBSERVED      <- "NOT_OBSERVED"
.USAGE_UNCLEAR           <- "UNCLEAR"
.USAGE_NO_DATA           <- "NO_DATA"
.USAGE_PARTIAL           <- "PARTIAL"
.USAGE_NOT_USED          <- "NOT_USED"
.USAGE_NOT_MEASURABLE    <- "NOT_MEASURABLE"
.USAGE_PARTLY_MEASURABLE <- "PARTLY_MEASURABLE"

.UNKNOWN_ROLE_LABEL <- "(unknown role)"

.check_role_report <- function(role_report, required_tables) {

  is_report <- is.list(role_report) &&
    !is.data.frame(role_report) &&
    all(required_tables %in% names(role_report))

  if (!is_report) {
    stop(
      "role_report must be the result of build_role_license_report() or ",
      "analyze_role_license_report()."
    )
  }

  invisible(role_report)
}

# The telemetry of the role, read and checked once:
#   checked     all touches in the form analyze_user_duty_usage() accepts, so
#               that the check of the names (and its warning) runs only here
#   known_users users of the role that occur in the telemetry at all
#   per_object  touches of these users on the role's objects
.role_object_touches <- function(drivers, usage, user_ids) {

  user_keys        <- tolower(user_ids)
  role_entrypoints <- .distinct_duty_entrypoints(drivers)

  checked <- .normalize_usage(usage) |>
    .drop_unmatched_usage(role_entrypoints)
  own     <- dplyr::filter(checked, USER_KEY %in% user_keys)

  per_object <- own |>
    dplyr::filter(ENTRYPOINT_KEY %in% role_entrypoints$ENTRYPOINT_KEY) |>
    dplyr::group_by(USER_KEY, ENTRYPOINT_KEY) |>
    dplyr::summarise(
      TOUCHES   = sum(TOUCHES, na.rm = TRUE),
      LAST_SEEN = .max_date(LAST_SEEN),
      .groups   = "drop"
    )

  list(
    checked     = dplyr::select(checked, USERID = USER_KEY, ENTRYPOINT = ENTRYPOINT_KEY, TOUCHES, LAST_SEEN),
    known_users = unique(own$USER_KEY),
    per_object  = per_object
  )
}

# Licenses that only one SKU covers, with the share of measurable objects.
.fixing_licenses <- function(object_needs, min_measurable_share) {
  object_needs |>
    dplyr::filter(.is_fixing_need(NEED, IS_BASE)) |>
    dplyr::group_by(SKUNAME = NEED) |>
    dplyr::summarise(
      NEED_PRIORITY       = dplyr::first(NEED_PRIORITY),
      FIXING_OBJECT_COUNT = dplyr::n(),
      MEASURABLE_COUNT    = sum(MEASURABLE),
      .groups             = "drop"
    ) |>
    dplyr::mutate(
      JUDGEABLE = MEASURABLE_COUNT > 0L &
        MEASURABLE_COUNT / FIXING_OBJECT_COUNT >= min_measurable_share
    ) |>
    dplyr::arrange(NEED_PRIORITY, SKUNAME)
}

.rate_user_licenses <- function(users, licenses, object_needs, object_touches) {

  fixing_objects <- object_needs |>
    dplyr::filter(.is_fixing_need(NEED, IS_BASE)) |>
    dplyr::select(SKUNAME = NEED, ENTRYPOINT_KEY)

  license_touches <- object_touches |>
    dplyr::inner_join(fixing_objects, by = "ENTRYPOINT_KEY") |>
    dplyr::group_by(USER_KEY, SKUNAME) |>
    dplyr::summarise(TOUCHES = sum(TOUCHES), .groups = "drop")

  tidyr::expand_grid(users, dplyr::select(licenses, SKUNAME, NEED_PRIORITY, JUDGEABLE)) |>
    dplyr::left_join(license_touches, by = c("USER_KEY", "SKUNAME")) |>
    dplyr::mutate(
      TOUCHES = dplyr::coalesce(TOUCHES, 0),
      STATUS  = dplyr::case_when(
        !HAS_USAGE_DATA ~ .USAGE_NO_DATA,
        TOUCHES > 0     ~ .USAGE_USED,
        JUDGEABLE       ~ .USAGE_NOT_OBSERVED,
        TRUE            ~ .USAGE_UNCLEAR
      )
    ) |>
    dplyr::arrange(USERID, NEED_PRIORITY, SKUNAME)
}

# Objects of every block: whether the block grants them at base license level
# and whether the telemetry can see them.
.block_parts <- function(role_report) {
  role_report$BlockObjects |>
    dplyr::group_by(BLOCK_TYPE, BLOCK_ID, ENTRYPOINT_KEY) |>
    dplyr::summarise(ROW_IS_BASE = any(ROW_IS_BASE), .groups = "drop") |>
    dplyr::left_join(
      dplyr::select(role_report$ObjectNeeds, ENTRYPOINT_KEY, MEASURABLE),
      by = "ENTRYPOINT_KEY"
    ) |>
    dplyr::mutate(MEASURABLE = dplyr::coalesce(MEASURABLE, FALSE))
}

.block_touches <- function(block_parts, object_touches) {
  block_parts |>
    dplyr::inner_join(object_touches, by = "ENTRYPOINT_KEY", relationship = "many-to-many") |>
    dplyr::group_by(USER_KEY, BLOCK_TYPE, BLOCK_ID) |>
    dplyr::summarise(
      # BASE_TOUCHES before TOUCHES: summarise() overwrites TOUCHES at once
      BASE_TOUCHES = sum(TOUCHES[ROW_IS_BASE]),
      TOUCHES      = sum(TOUCHES),
      LAST_SEEN    = .max_date(LAST_SEEN),
      .groups      = "drop"
    )
}

# A block whose base license part holds no form cannot be judged: "not
# opened" would say nothing about its actions.
.rate_user_blocks <- function(users, role_report, object_touches) {

  block       <- c("BLOCK_TYPE", "BLOCK_ID")
  block_parts <- .block_parts(role_report)

  base_blocks <- role_report$Blocks |>
    dplyr::filter(IS_BASE) |>
    dplyr::select(BLOCK_TYPE, BLOCK_ID, BLOCK_NAME, NEED)

  measurability <- block_parts |>
    dplyr::group_by(BLOCK_TYPE, BLOCK_ID) |>
    dplyr::summarise(
      BASE_OBJECT_COUNT     = sum(ROW_IS_BASE),
      BASE_MEASURABLE_COUNT = sum(ROW_IS_BASE & MEASURABLE),
      .groups               = "drop"
    )

  tidyr::expand_grid(users, dplyr::left_join(base_blocks, measurability, by = block)) |>
    dplyr::left_join(.block_touches(block_parts, object_touches), by = c("USER_KEY", block)) |>
    dplyr::mutate(
      TOUCHES      = dplyr::coalesce(TOUCHES, 0),
      BASE_TOUCHES = dplyr::coalesce(BASE_TOUCHES, 0),
      RATING       = dplyr::case_when(
        !HAS_USAGE_DATA             ~ .USAGE_NO_DATA,
        BASE_TOUCHES > 0            ~ .USAGE_USED,
        BASE_MEASURABLE_COUNT == 0L ~ .USAGE_NOT_MEASURABLE,
        TOUCHES > 0                 ~ .USAGE_PARTIAL,
        TRUE                        ~ .USAGE_NOT_USED
      )
    ) |>
    dplyr::select(
      USERID, BLOCK_TYPE, BLOCK_ID, BLOCK_NAME, NEED, TOUCHES, BASE_TOUCHES,
      BASE_OBJECT_COUNT, BASE_MEASURABLE_COUNT, LAST_SEEN, RATING
    ) |>
    dplyr::arrange(BLOCK_TYPE, BLOCK_ID, USERID)
}

# Rates each duty over all users, in line with the evidence per user: a duty
# with a license part the telemetry cannot see is not "unused". Without
# telemetry for any user, "nobody opened it" would say nothing.
.summarize_duty_usage <- function(duty_usage, has_usage_data) {
  duty_usage |>
    dplyr::filter(DUTYIDENTIFIER != .DIRECT_DUTY_ID) |>
    dplyr::group_by(DUTYIDENTIFIER, DUTYNAME) |>
    dplyr::summarise(
      USERS_WITH_USE        = sum(TOUCHES > 0),
      TOUCHES               = sum(TOUCHES),
      LAST_SEEN             = .max_date(LAST_SEEN),
      MEASURABLE_COUNT      = dplyr::first(MEASURABLE_COUNT),
      ENTRYPOINT_COUNT      = dplyr::first(ENTRYPOINT_COUNT),
      UNMEASURABLE_LICENSES = dplyr::first(UNMEASURABLE_LICENSES),
      .groups               = "drop"
    ) |>
    dplyr::mutate(
      RATING = dplyr::case_when(
        USERS_WITH_USE > 0L         ~ .USAGE_USED,
        !has_usage_data             ~ .USAGE_NO_DATA,
        MEASURABLE_COUNT == 0L      ~ .USAGE_NOT_MEASURABLE,
        UNMEASURABLE_LICENSES != "" ~ .USAGE_PARTLY_MEASURABLE,
        TRUE                        ~ .USAGE_NOT_USED
      )
    ) |>
    dplyr::arrange(USERS_WITH_USE, DUTYIDENTIFIER)
}

# Other roles of the users that trigger a base license this role needs too.
# Rows without a role name stay visible as "(unknown role)".
.other_role_licenses <- function(users, user_licenses, role_report, role_identifier) {

  empty <- tibble::tibble(
    USER_KEY = character(), USERID = character(), SKUNAME = character(),
    ROLEIDENTIFIER = character(), SECURITYROLENAME = character()
  )

  if (is.null(user_licenses) || nrow(user_licenses) == 0L) {
    return(empty)
  }

  .check_required_columns(user_licenses, c("USERID", "ROLEIDENTIFIER", "SKUNAME"), "user_licenses")

  base_needs <- c(
    role_report$Blocks$NEED[role_report$Blocks$IS_BASE],
    role_report$ObjectNeeds$NEED[role_report$ObjectNeeds$IS_BASE]
  )
  role_skus <- setdiff(unique(unlist(.split_skus(base_needs))), .NEED_MULTIPLE)
  role_name <- if ("SECURITYROLENAME" %in% names(user_licenses)) user_licenses$SECURITYROLENAME else NA_character_

  user_licenses |>
    dplyr::mutate(USER_KEY = tolower(USERID), SECURITYROLENAME = as.character(role_name)) |>
    dplyr::filter(
      USER_KEY %in% users$USER_KEY,
      SKUNAME %in% role_skus,
      is.na(ROLEIDENTIFIER) | toupper(ROLEIDENTIFIER) != toupper(role_identifier)
    ) |>
    dplyr::mutate(ROLEIDENTIFIER = dplyr::coalesce(ROLEIDENTIFIER, .UNKNOWN_ROLE_LABEL)) |>
    dplyr::distinct(USER_KEY, SKUNAME, ROLEIDENTIFIER, SECURITYROLENAME) |>
    dplyr::inner_join(dplyr::select(users, USER_KEY, USERID), by = "USER_KEY") |>
    dplyr::select(USER_KEY, USERID, SKUNAME, ROLEIDENTIFIER, SECURITYROLENAME) |>
    dplyr::arrange(USERID, SKUNAME, ROLEIDENTIFIER)
}

.summarize_users <- function(users, rated_licenses, duty_usage, object_touches,
                             user_licenses, other_roles) {

  with_status <- function(sku, sku_status, status) {
    paste(sku[sku_status == status], collapse = .SKU_SEPARATOR)
  }

  statuses <- rated_licenses |>
    dplyr::arrange(NEED_PRIORITY, SKUNAME) |>
    dplyr::group_by(USER_KEY) |>
    dplyr::summarise(
      LICENSES_USED         = with_status(SKUNAME, STATUS, .USAGE_USED),
      LICENSES_NOT_OBSERVED = with_status(SKUNAME, STATUS, .USAGE_NOT_OBSERVED),
      LICENSES_UNCLEAR      = with_status(SKUNAME, STATUS, .USAGE_UNCLEAR),
      .groups               = "drop"
    )

  duties <- duty_usage |>
    dplyr::filter(DUTYIDENTIFIER != .DIRECT_DUTY_ID) |>
    dplyr::group_by(USER_KEY = tolower(USERID)) |>
    dplyr::summarise(DUTIES_USED = sum(TOUCHES > 0), DUTY_COUNT = dplyr::n(), .groups = "drop")

  last_seen <- object_touches |>
    dplyr::group_by(USER_KEY) |>
    dplyr::summarise(LAST_SEEN = .max_date(LAST_SEEN), .groups = "drop")

  via_other <- other_roles |>
    dplyr::group_by(USER_KEY) |>
    dplyr::summarise(VIA_OTHER_ROLES = .collapse_sorted(SKUNAME), .groups = "drop")

  users |>
    dplyr::left_join(statuses, by = "USER_KEY") |>
    dplyr::left_join(duties, by = "USER_KEY") |>
    dplyr::left_join(last_seen, by = "USER_KEY") |>
    dplyr::left_join(.licenses_today(user_licenses), by = "USER_KEY") |>
    dplyr::left_join(via_other, by = "USER_KEY") |>
    dplyr::mutate(
      dplyr::across(
        c(LICENSES_USED, LICENSES_NOT_OBSERVED, LICENSES_UNCLEAR, LICENSES_TODAY, VIA_OTHER_ROLES),
        function(x) dplyr::coalesce(x, "")
      ),
      DUTIES_USED = dplyr::coalesce(DUTIES_USED, 0L),
      DUTY_COUNT  = dplyr::coalesce(DUTY_COUNT, 0L)
    ) |>
    dplyr::select(
      USERID, HAS_USAGE_DATA, LICENSES_USED, LICENSES_NOT_OBSERVED, LICENSES_UNCLEAR,
      DUTIES_USED, DUTY_COUNT, LAST_SEEN, LICENSES_TODAY, VIA_OTHER_ROLES
    ) |>
    dplyr::arrange(USERID)
}

# All licenses D365FO assigns to a user today, over all roles.
.licenses_today <- function(user_licenses) {

  if (is.null(user_licenses) || nrow(user_licenses) == 0L) {
    return(tibble::tibble(USER_KEY = character(), LICENSES_TODAY = character()))
  }

  user_licenses |>
    dplyr::filter(!is.na(USERID), !is.na(SKUNAME)) |>
    dplyr::group_by(USER_KEY = tolower(USERID)) |>
    dplyr::summarise(LICENSES_TODAY = .collapse_sorted(SKUNAME), .groups = "drop")
}
