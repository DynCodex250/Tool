# =============================================================================
# License graph of a role
#
# Used by analyze_role_license_report(). From version 10.0.47 (preview) D365FO
# keeps the table LicensingSecurityObjectExplodedGraph: one row per path
# role - sub-role - duty - privilege - object, with the access level and the
# license the object needs. It is the source of the tab "Security object
# licenses" of the form User Security Governance.
#
# This file loads the rows of a role and brings them into the two shapes
# build_role_license_drivers() works on: role objects and license rows.
#
# The table holds only objects that take part in licensing. Duties and
# privileges without such an object are added from UserSecGovRelatedObjects.
# =============================================================================

# Where a report took its data from (Role$SOURCE).
.SOURCE_GRAPH <- "graph"
.SOURCE_VIEWS <- "views"

.LICENSE_GRAPH_TABLE <- "LicensingSecurityObjectExplodedGraph"

# How SQL Server reports a table that does not exist: the SQLSTATE, or the
# message in English or German. The umlaut of the German message is left open,
# because the driver can deliver it in another encoding.
.MISSING_TABLE_PATTERN <- "42S02|Invalid object name|Ung.{1,4}ltiger Objektname"

# The table stores the type of an object as a number.
.SECURABLE_TYPE_NAMES <- c(
  "1"   = "MenuItemDisplay",
  "2"   = "MenuItemOutput",
  "3"   = "MenuItemAction",
  "11"  = "FormControl",
  "18"  = "Report",
  "44"  = "TableField",
  "45"  = "ClassMethod",
  "55"  = "WebUrlItem",
  "56"  = "WebActionItem",
  "57"  = "WebDisplayContentItem",
  "58"  = "WebOutputContentItem",
  "59"  = "WebletItem",
  "67"  = "DataEntity",
  "73"  = "WebControl",
  "75"  = "WebManagedContentItem",
  "76"  = "ServiceOperation",
  "81"  = "InfoPart",
  "82"  = "FormPart",
  "85"  = "SSRSReport",
  "115" = "CodePermission",
  "143" = "FormDatasource",
  "146" = "DataEntityMethod"
)

# The column LICENSE names the smallest sufficient license, with alternatives:
# "Commerce or Finance". "None" stands for an object that needs no license.
.GRAPH_LICENSE_SEPARATOR <- " or "
.GRAPH_NO_LICENSE        <- "None"

# The light license that includes Team Members.
.ACTIVITY_SKU <- "Operations - Activity"

.GRAPH_COLUMNS <- c(
  "ROLEIDENTIFIER", "ROLENAME", "SUBROLEIDENTIFIER", "SUBROLENAME",
  "DUTYIDENTIFIER", "DUTYNAME", "PRIVILEGEIDENTIFIER", "PRIVILEGENAME",
  "SECURABLETYPE", "SECURABLENAME", "SECURABLECHILDNAME", "ACCESSLEVEL", "LICENSE"
)

.load_role_license_graph <- function(con, role_identifier) {

  query <- paste0(
    "SELECT ", paste(.GRAPH_COLUMNS, collapse = ", "),
    " FROM ", toupper(.LICENSE_GRAPH_TABLE),
    " WHERE ROLEIDENTIFIER = ", DBI::dbQuoteString(con, role_identifier)
  )

  DBI::dbGetQuery(con, query) |>
    tibble::as_tibble()
}

# All license SKUs with their priority and group.
.load_license_skus <- function(con) {
  DBI::dbGetQuery(con, "SELECT SKUNAME, PRIORITY, GROUPNAME FROM LICENSINGALLSKUS") |>
    tibble::as_tibble()
}

# The graph of the role and the SKUs, or NULL with a message when the database
# does not have them: the table is part of a preview feature and filled by a
# job, so it can be missing or empty.
.load_available_license_graph <- function(con, role_identifier) {

  # Only a missing table leads to the other source. Any other failure, such
  # as a missing permission or a timeout, stops the run: the other source is
  # less exact, and it must not take over unnoticed.
  loaded <- tryCatch(
    list(graph = .load_role_license_graph(con, role_identifier), skus = .load_license_skus(con)),
    error = function(e) {
      reason <- .without_sql_statement(conditionMessage(e))
      if (!grepl(.MISSING_TABLE_PATTERN, reason, ignore.case = TRUE)) {
        stop("Reading the license graph (", .LICENSE_GRAPH_TABLE, ") failed: ", reason, call. = FALSE)
      }
      reason
    }
  )

  reason <- if (is.character(loaded)) {
    loaded
  } else if (nrow(loaded$graph) == 0L) {
    "it holds no rows for this role"
  } else if (nrow(loaded$skus) == 0L) {
    "the list of licenses (LicensingAllSkus) is empty"
  }

  if (is.null(reason)) {
    return(loaded)
  }

  message(
    "Role '", role_identifier, "': the license graph (", .LICENSE_GRAPH_TABLE, ") is not ",
    "used: ", reason, ". The report is built from the security objects and the license views."
  )

  NULL
}

# Role objects in the columns of UserSecGovRelatedObjects.
.role_objects_from_graph <- function(graph) {

  .check_required_columns(graph, .GRAPH_COLUMNS, "the license graph")

  type_id   <- as.character(graph$SECURABLETYPE)
  type_name <- unname(.SECURABLE_TYPE_NAMES[type_id])
  unmapped  <- unique(type_id[is.na(type_name)])

  if (length(unmapped) > 0L) {
    warning(
      "The license graph holds object types the package does not know: ",
      paste(unmapped, collapse = .LIST_SEPARATOR), ". Their objects are not counted as measurable.",
      call. = FALSE
    )
  }

  tibble::tibble(
    ROLEIDENTIFIER      = graph$ROLEIDENTIFIER,
    ROLENAME            = graph$ROLENAME,
    SUBROLEIDENTIFIER   = dplyr::coalesce(as.character(graph$SUBROLEIDENTIFIER), ""),
    SUBROLENAME         = dplyr::coalesce(as.character(graph$SUBROLENAME), ""),
    DUTYIDENTIFIER      = dplyr::coalesce(as.character(graph$DUTYIDENTIFIER), ""),
    DUTYNAME            = dplyr::coalesce(as.character(graph$DUTYNAME), ""),
    PRIVILEGEIDENTIFIER = graph$PRIVILEGEIDENTIFIER,
    PRIVILEGENAME       = graph$PRIVILEGENAME,
    RESOURCE_           = graph$SECURABLENAME,
    RESOURCETYPE        = dplyr::coalesce(type_name, paste("SecurableType", type_id))
  ) |>
    dplyr::distinct()
}

# The privileges the graph does not list hold no object that takes part in
# licensing. They are added so that their duties stay in the report.
.add_unlicensed_privileges <- function(graph_objects, security_objects) {

  if (is.null(security_objects)) {
    return(graph_objects)
  }

  in_graph <- .identifier_key(security_objects$PRIVILEGEIDENTIFIER) %in%
    .identifier_key(graph_objects$PRIVILEGEIDENTIFIER)

  added <- security_objects[!in_graph, ] |>
    dplyr::select(dplyr::any_of(names(graph_objects))) |>
    dplyr::mutate(dplyr::across(dplyr::everything(), as.character)) |>
    .spell_like_graph(graph_objects)

  dplyr::bind_rows(graph_objects, added)
}

# The two sources write the same identifier in different case, for example
# TRADESALESCLERK and TradeSalesClerk. Added rows take the spelling and the
# name the graph uses, so that a sub-role or duty does not appear twice.
.spell_like_graph <- function(added, graph_objects) {

  like_graph <- function(identifiers, column) {
    in_graph <- graph_objects[[column]][match(.identifier_key(identifiers), .identifier_key(graph_objects[[column]]))]
    dplyr::coalesce(in_graph, identifiers)
  }
  name_in_graph <- function(identifiers, id_column, name_column, names) {
    in_graph <- graph_objects[[name_column]][match(.identifier_key(identifiers), .identifier_key(graph_objects[[id_column]]))]
    dplyr::coalesce(in_graph, names)
  }

  dplyr::mutate(
    added,
    ROLEIDENTIFIER    = graph_objects$ROLEIDENTIFIER[[1]],
    ROLENAME          = graph_objects$ROLENAME[[1]],
    SUBROLEIDENTIFIER = dplyr::coalesce(SUBROLEIDENTIFIER, ""),
    DUTYIDENTIFIER    = dplyr::coalesce(DUTYIDENTIFIER, ""),
    SUBROLENAME       = name_in_graph(SUBROLEIDENTIFIER, "SUBROLEIDENTIFIER", "SUBROLENAME", SUBROLENAME),
    DUTYNAME          = name_in_graph(DUTYIDENTIFIER, "DUTYIDENTIFIER", "DUTYNAME", DUTYNAME),
    SUBROLEIDENTIFIER = like_graph(SUBROLEIDENTIFIER, "SUBROLEIDENTIFIER"),
    DUTYIDENTIFIER    = like_graph(DUTYIDENTIFIER, "DUTYIDENTIFIER")
  )
}

# The licenses that cover an object, from the text of the column LICENSE.
#
# The text names the smallest sufficient license. Larger licenses cover too:
#   None                  every license
#   Team Members          Operations - Activity and every base license
#   Operations - Activity every base license
#   base licenses         the Premium license of the same name
# Other light licenses, such as Human Resources Self Service, cover only the
# objects that need no license.
#
# A license the license list does not hold is left out: nothing is known
# about what it covers, so no other license is put in its place.
.graph_covering_skus <- function(license, skus, base_group_pattern) {

  if (is.na(license) || !nzchar(license)) {
    return(character())
  }
  if (.identifier_key(license) == .identifier_key(.GRAPH_NO_LICENSE)) {
    return(skus$SKUNAME)
  }

  # in the spelling of the license list
  named <- .split_graph_license(license)
  named <- skus$SKUNAME[match(.identifier_key(named), .identifier_key(skus$SKUNAME))]
  named <- named[!is.na(named)]
  base  <- skus$SKUNAME[.is_base_group(skus$GROUPNAME, base_group_pattern)]

  if (length(named) == 0L) {
    return(character())
  }
  if (all(named %in% base)) {
    return(union(named, intersect(paste0(named, .PREMIUM_SUFFIX), skus$SKUNAME)))
  }

  larger_light <- if (any(grepl(.LICENSE_FLOOR_PATTERN, named))) {
    intersect(.ACTIVITY_SKU, skus$SKUNAME)
  }

  unique(c(named, larger_light, base))
}

.split_graph_license <- function(license) {
  trimws(strsplit(license, .GRAPH_LICENSE_SEPARATOR, fixed = TRUE)[[1]])
}

# License names of the graph that the license list does not hold.
.unknown_graph_licenses <- function(licenses, skus) {

  named <- unique(unlist(lapply(licenses[!is.na(licenses) & nzchar(licenses)], .split_graph_license)))
  named <- named[.identifier_key(named) != .identifier_key(.GRAPH_NO_LICENSE)]

  named[!.identifier_key(named) %in% .identifier_key(skus$SKUNAME)]
}

# Both cases make an object count as not covered. That is the careful reading,
# and the user has to know that it was applied.
.warn_about_graph_licenses <- function(licenses, skus) {

  without_license <- sum(is.na(licenses) | !nzchar(licenses))
  unknown         <- .unknown_graph_licenses(licenses, skus)

  if (without_license > 0L) {
    warning(
      without_license, " rows of the license graph name no license. ",
      "Their objects are not counted as covered by any license.",
      call. = FALSE
    )
  }
  if (length(unknown) > 0L) {
    warning(
      "The license graph names licenses that LicensingAllSkus does not list: ",
      paste(unknown, collapse = .LIST_SEPARATOR), ". They are not counted as covering any object.",
      call. = FALSE
    )
  }
}

# License rows in the columns of LicensingPrivilegeRequirementsDetailedView:
# one row per privilege, object, access level and covering license.
#
# The graph lists an object once per type and child object. The report knows
# an object by its name, so a name with several entries takes its strictest
# one: a license covers it only when it covers every entry.
.license_rows_from_graph <- function(graph, skus, base_group_pattern) {

  .warn_about_graph_licenses(graph$LICENSE, skus)

  licenses <- unique(graph$LICENSE)
  covering <- lapply(licenses, .graph_covering_skus, skus = skus, base_group_pattern = base_group_pattern)

  tibble::tibble(
    IDENTIFIER  = graph$PRIVILEGEIDENTIFIER,
    AOTNAME     = graph$SECURABLENAME,
    OBJECT_KEY  = .identifier_key(graph$SECURABLENAME),
    ACCESSLEVEL = as.numeric(graph$ACCESSLEVEL),
    COVERING    = covering[match(graph$LICENSE, licenses)]
  ) |>
    dplyr::group_by(IDENTIFIER, OBJECT_KEY, ACCESSLEVEL) |>
    dplyr::summarise(
      AOTNAME = dplyr::first(AOTNAME),
      SKUNAME = list(Reduce(intersect, COVERING)),
      .groups = "drop"
    ) |>
    tidyr::unnest(SKUNAME, keep_empty = TRUE) |>
    dplyr::left_join(dplyr::select(skus, SKUNAME, PRIORITY, GROUPNAME), by = "SKUNAME") |>
    dplyr::mutate(ENTITLED = dplyr::if_else(is.na(SKUNAME), 0L, 1L)) |>
    dplyr::select(IDENTIFIER, AOTNAME, ACCESSLEVEL, SKUNAME, PRIORITY, GROUPNAME, ENTITLED)
}
